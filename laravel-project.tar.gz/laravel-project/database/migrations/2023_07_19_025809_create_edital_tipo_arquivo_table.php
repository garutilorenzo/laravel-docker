<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('edital_tipo_arquivo', function (Blueprint $table) {
            $table->id();
            $table->foreignId('edital_id')->constrained('editais')->onDelete('cascade')->onUpdate('cascade')->nullable();
            $table->foreignId('tipo_arquivo_id')->constrained('tipo_arquivos')->onDelete('cascade')->onUpdate('cascade')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('edital_tipo_arquivo');
    }
};
