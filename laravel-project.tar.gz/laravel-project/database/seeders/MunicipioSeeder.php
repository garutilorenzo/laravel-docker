<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Municipio;

class MunicipioSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Municipio::create([
            'nome' => 'Goiânia',
            'situacao' => 'Ativo',
            'uf' => 'Goiás',
        ]);

        Municipio::create([
            'nome' => 'Aruana',
            'situacao' => 'Ativo',
            'uf' => 'Goiás',
        ]);

        Municipio::create([
            'nome' => 'Anapólis',
            'situacao' => 'Ativo',
            'uf' => 'Goiás',
        ]);

        Municipio::create([
            'nome' => 'Abadiana',
            'situacao' => 'Ativo',
            'uf' => 'Goiás',
        ]);
    }
}
