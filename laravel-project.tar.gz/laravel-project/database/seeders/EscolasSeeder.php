<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Escola;

class EscolasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Escola::create([
            'nome' => 'Colégio Auxilio Das Esperanãs',
            'situacao' => 'Ativo',
            'rede' => 'COTEC',
            'ficha' => '001',
            'endereco_completo' => 'Rua irlanda, 00, Jardim Europa',
            'contato' => '62991615681',
            'municipio_id' => '1',
            'user_id' => '1',
        ]);

        Escola::create([
            'nome' => 'Colegio Das Esperanças dos Auxiliadores',
            'situacao' => 'Ativo',
            'rede' => 'EFG',
            'ficha' => '002',
            'endereco_completo' => 'Rua irlanda, 00, Jardim Europa',
            'contato' => '62991615681',
            'municipio_id' => '1',
            'user_id' => '1',
        ]);

        Escola::create([
            'nome' => 'Colégio dos Pirineus',
            'situacao' => 'Ativo',
            'rede' => 'GOIAS TEC',
            'ficha' => '003',
            'endereco_completo' => 'Rua irlanda, 00, Jardim Europa',
            'contato' => '62991615681',
            'municipio_id' => '1',
            'user_id' => '1',
        ]);

        Escola::create([
            'nome' => 'Colégio Dos Pinhais',
            'situacao' => 'Ativo',
            'rede' => 'JUVENTUDE',
            'ficha' => '004',
            'endereco_completo' => 'Rua irlanda, 00, Jardim Europa',
            'contato' => '62991615681',
            'municipio_id' => '1',
            'user_id' => '1',
        ]);
    }
}
