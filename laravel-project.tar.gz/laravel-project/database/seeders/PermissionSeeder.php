<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;


class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Grupos
        $admin = Role::create(['name' => 'Admin']);
        $secretaria = Role::create(['name' => 'Secretaria']);
        $usuario = Role::create(['name' => 'Usuario']);
        $escola = Role::create(['name' => 'Escola']);

        // Inscricoes
        $inscricoes_index = Permission::create(['name' => 'Index Inscricoes']); 
        $inscricoes_criar = Permission::create(['name' => 'Criar Inscricoes']);
        $inscricoes_editar = Permission::create(['name' => 'Editar Inscricoes']);
        $inscricoes_deletar = Permission::create(['name' => 'Excluir Inscricoes']);
        $inscricoes_importar = Permission::create(['name' => 'Importar Inscricoes']);
        $inscricoes_exportar = Permission::create(['name' => 'Exportar Inscricoes']);
        $inscricoes_topbar = Permission::create(['name' => 'Sidebar Inscricoes']);
        $inscricoes_permissoes = [$inscricoes_index, $inscricoes_criar, $inscricoes_editar, $inscricoes_deletar, $inscricoes_importar, $inscricoes_importar,$inscricoes_exportar, $inscricoes_topbar];

        // Cursos
        $cursos_index = Permission::create(['name' => 'Index Cursos']); 
        $cursos_criar = Permission::create(['name' => 'Criar Cursos']);
        $cursos_editar = Permission::create(['name' => 'Editar Cursos']);
        $cursos_deletar = Permission::create(['name' => 'Excluir Cursos']);
        $cursos_importar = Permission::create(['name' => 'Importar Cursos']);
        $cursos_exportar = Permission::create(['name' => 'Exportar Cursos']);
        $cursos_topbar = Permission::create(['name' => 'Sidebar Cursos']);
        $cursos_permissoes = [$cursos_index, $cursos_criar, $cursos_editar, $cursos_deletar, $cursos_importar, $cursos_importar,$cursos_exportar, $cursos_topbar];

        // Turmas
        $turmas_index = Permission::create(['name' => 'Index Turmas']); 
        $turmas_criar = Permission::create(['name' => 'Criar Turmas']);
        $turmas_editar = Permission::create(['name' => 'Editar Turmas']);
        $turmas_deletar = Permission::create(['name' => 'Excluir Turmas']);
        $turmas_importar = Permission::create(['name' => 'Importar Turmas']);
        $turmas_exportar = Permission::create(['name' => 'Exportar Turmas']);
        $turmas_topbar = Permission::create(['name' => 'Sidebar Turmas']);
        $turmas_permissoes = [$turmas_index, $turmas_criar, $turmas_editar, $turmas_deletar, $turmas_importar, $turmas_importar,$turmas_exportar, $turmas_topbar];

        // Arquivos
        $arquivos_index = Permission::create(['name' => 'Index Arquivos']); 
        $arquivos_criar = Permission::create(['name' => 'Criar Arquivos']);
        $arquivos_editar = Permission::create(['name' => 'Editar Arquivos']);
        $arquivos_deletar = Permission::create(['name' => 'Excluir Arquivos']);
        $arquivos_importar = Permission::create(['name' => 'Importar Arquivos']);
        $arquivos_exportar = Permission::create(['name' => 'Exportar Arquivos']);
        $arquivos_topbar = Permission::create(['name' => 'Topbar Arquivos']);
        $arquivos_permissoes = [$arquivos_index, $arquivos_criar, $arquivos_editar, $arquivos_deletar, $arquivos_importar, $arquivos_importar,$arquivos_exportar, $arquivos_topbar];

        // Tags
        $tags_index = Permission::create(['name' => 'Index Tags']); 
        $tags_criar = Permission::create(['name' => 'Criar Tags']);
        $tags_editar = Permission::create(['name' => 'Editar Tags']);
        $tags_deletar = Permission::create(['name' => 'Excluir Tags']);
        $tags_importar = Permission::create(['name' => 'Importar Tags']);
        $tags_exportar = Permission::create(['name' => 'Exportar Tags']);
        $tags_topbar = Permission::create(['name' => 'Topbar Tags']);
        $tags_permissoes = [$tags_index, $tags_criar, $tags_editar, $tags_deletar, $tags_importar, $tags_importar,$tags_exportar, $tags_topbar];

        // Escolas
        $escola_index = Permission::create(['name' => 'Index Escolas']); 
        $escola_criar = Permission::create(['name' => 'Criar Escolas']);
        $escola_editar = Permission::create(['name' => 'Editar Escolas']);
        $escola_deletar = Permission::create(['name' => 'Excluir Escolas']);
        $escola_importar = Permission::create(['name' => 'Importar Escolas']);
        $escola_exportar = Permission::create(['name' => 'Exportar Escolas']);
        $escola_topbar = Permission::create(['name' => 'Topbar Escolas']);
        $escola_permissoes = [$escola_index, $escola_criar, $escola_editar, $escola_deletar, $escola_importar, $escola_importar,$escola_exportar, $escola_topbar];

        // Usuário
        $usuario_index = Permission::create(['name' => 'Index Usuarios']); 
        $usuario_criar = Permission::create(['name' => 'Criar Usuarios']);
        $usuario_editar = Permission::create(['name' => 'Editar Usuarios']);
        $usuario_deletar = Permission::create(['name' => 'Excluir Usuarios']);
        $usuario_importar = Permission::create(['name' => 'Importar Usuarios']);
        $usuario_exportar = Permission::create(['name' => 'Exportar Usuarios']);
        $usuario_topbar = Permission::create(['name' => 'Topbar Usuarios']);
        $usuario_permissoes = [$usuario_index, $usuario_criar, $usuario_editar, $usuario_deletar, $usuario_importar, $usuario_importar,$usuario_exportar, $usuario_topbar];

        //niveis de Acessos
        $niveis_de_acesso_index = Permission::create(['name' => 'Index Nivel de Acesso']);
        $niveis_de_acesso_criar = Permission::create(['name' => 'Criar Nivel de Acesso']);
        $niveis_de_acesso_editar = Permission::create(['name' => 'Editar Nivel de Acesso']);
        $niveis_de_acesso_deletar = Permission::create(['name' => 'Excluir Nivel de Acesso']);
        $niveis_de_acesso_topbar = Permission::create(['name' => 'Topbar Nivel de Acesso']);
        $niveis_de_acesso_permissoes = [$niveis_de_acesso_index, $niveis_de_acesso_criar, $niveis_de_acesso_editar, $niveis_de_acesso_deletar,$niveis_de_acesso_topbar];

        // permissoes
        $permissao_index = Permission::create(['name' => 'Index Permissoes']);
        $permissao_criar = Permission::create(['name' => 'Criar Permissoes']);
        $permissao_editar = Permission::create(['name' => 'Editar Permissoes']);
        $permissao_deletar = Permission::create(['name' => 'Excluir Permissoes']);
        $permissao_topbar = Permission::create(['name' => 'Topbar Permissoes']);
        $permissao_permissoes = [$permissao_index, $permissao_criar, $permissao_editar, $permissao_deletar, $permissao_topbar];
        
        // Editais

        $edital_listar = Permission::create(['name' => 'Index Editais']);
        $edital_criar = Permission::create(['name' => 'Criar Editais']);
        $edital_editar = Permission::create(['name' => 'Editar Editais']);
        $edital_deletar = Permission::create(['name' => 'Excluir Editais']);
        $edital_importar = Permission::create(['name' => 'Importar Editais']);
        $edital_exportar = Permission::create(['name' => 'Exportar Editais']);
        $edital_sidebar = Permission::create(['name' => 'Sidebar Editais']);
        $edital_permissoes = [$edital_criar, $edital_editar, $edital_listar, $edital_deletar, $edital_importar, $edital_exportar, $edital_sidebar];

        // Municípios

        $municipio_listar = Permission::create(['name' => 'Index Municipios']);
        $municipio_criar = Permission::create(['name' => 'Criar Municipios']);
        $municipio_editar = Permission::create(['name' => 'Editar Municipios']);
        $municipio_deletar = Permission::create(['name' => 'Excluir Municipios']);
        $municipio_importar = Permission::create(['name' => 'Importar Municipios']);
        $municipio_exportar = Permission::create(['name' => 'Exportar Municipios']);
        $municipio_topbar = Permission::create(['name' => 'Topbar Municipios']);
        $municipio_permissoes = [$municipio_criar, $municipio_editar, $municipio_listar, $municipio_deletar, $municipio_importar, $municipio_exportar, $municipio_topbar];

        

        //Permissões por Grupo
        $permissoes_admin = array_merge($municipio_permissoes, $edital_permissoes, $permissao_permissoes, $niveis_de_acesso_permissoes, $usuario_permissoes, $escola_permissoes, $tags_permissoes, $arquivos_permissoes, $turmas_permissoes, $cursos_permissoes, $inscricoes_permissoes);
        
        $admin->syncPermissions($permissoes_admin);
    }
}
