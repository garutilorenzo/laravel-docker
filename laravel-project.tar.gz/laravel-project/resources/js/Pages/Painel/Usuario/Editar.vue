<template>
    <Head title="Turmas" />
    
    <AuthenticatedLayout>
        <div class="tw-flex tw-flex-1 tw-flex-col">
            <div class="tw-flex tw-flex-1 tw-flex-col tw-justify-start tw-bg-white tw-shadow sm:tw-rounded-lg tw-px-8 tw-py-4 tw-overflow-hidden tw-overflow-y-scroll">
                <div class="tw-flex md:tw-flex-row tw-flex-col tw-gap-4 tw-py-4 tw-items-center tw-justify-between items tw-border-b-2 tw-border-gray-200">
                    <h4 class="tw-text-navy-500 tw-font-title tw-font-semibold">{{ form.nome }}</h4>
                </div>

                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <p class="tw-flex tw-flex-1 tw-text-green-800 tw-text-lg tw-font-title tw-my-4">INFORMAÇÕES BÁSICAS</p>
                </div>

                <!-- Arquivos -->
                <!-- <div class="tw-flex tw-flex-row tw-flex-1 tw-gap-2 tw-items-start">
                    <div class="tw-flex tw-flex-col">
                        <q-file standout bg-color="blue" label-color="white" v-model="form.imagem" input-class="tw-text-gray-700 tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm" label="Anexar Imagem"
                            >
                            <template v-slot:prepend>
                                <Icon icon="ph:upload-light" class="tw-text-white"/>
                            </template>
                        </q-file>
                    </div>
                    <div class="tw-flex tw-flex-col tw-pt-4">
                        <p class="tw-text-base tw-text-gray-600">
                            {{ form.imagem.name }}
                        </p>
                    </div>
                    
                </div> -->
                
                <!-- Nome da Turma, Curso e Vagas -->

                <div class="tw-flex tw-flex-row tw-mt-8 md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <div class="tw-flex tw-flex-auto tw-w-80 tw-flex-col">
                        <InputLabel for="edital" value="Vincular Edital" required/>
                        <select
                            v-model="form.edital_id" id="edital" 
                            class="tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            >
                            <option v-for="edital, index of props.editais" :key="index" :value="edital.id">{{ edital.nome }}</option>
                        </select>
                    <InputError class="tw-mt-2" :message="form.errors.edital_id" />
                    </div>
    
                    <div class="tw-flex tw-flex-auto tw-w-0 tw-flex-col">
                        <InputLabel for="modelo" value="Vincular Curso" required/>
                        <select
                            v-model="form.curso_id" id="curso" 
                            class="tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                        >
                            <option v-for="curso, index of props.cursos" :key="index" :value="curso.id">{{ curso.nome }}</option>
                        </select>
                        <InputError class="tw-mt-2" :message="form.errors.curso_id" />
                    </div>                    
                </div>
    
                <!-- Tipo, Turno e Modalidade -->
                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="categoria" value="Categoria" required/>
                        <select
                            v-model="form.categoria" id="categoria" 
                            class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                        >
                            <option v-for="opcao in opcoesCategoria" :value="opcao">{{ opcao }}</option>
                        </select>
                        <InputError class="tw-mt-2" :message="form.errors.categoria" />
                    </div>
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="horas_curso" value="Carga Horária" required/>
                        <select
                            v-model="form.horas_curso" id="horas_curso" 
                            class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                        >
                            <option v-for="opcao in opcoesCargahoraria" :value="opcao">{{ opcao }}</option>
                        </select>
                        <InputError class="tw-mt-2" :message="form.errors.horas_curso" />
                    </div>
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="modalidade" value="Modalidade" required/>
                        <select
                            v-model="form.modalidade" id="modalidade" 
                            class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                        >
                            <option v-for="opcao in opcoesModalidade" :value="opcao">{{ opcao }}</option>
                        </select>
                        <InputError class="tw-mt-2" :message="form.errors.modalidade" />
                    </div>
                </div>
    
                <!-- Horas Curso, Nivel, Faixa Etaria -->
                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="nivel" value="Nivel" required/>
                        <select
                            v-model="form.nivel" id="nivel" 
                            class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                        >
                            <option v-for="opcao in opcoesNivel" :value="opcao">{{ opcao }}</option>
                        </select>
                        <InputError class="tw-mt-2" :message="form.errors.nivel" />
                    </div>
    
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="faixa_etaria" value="Faixa Etária" required/>
                        <select
                            v-model="form.faixa_etaria" id="faixa_etaria" 
                            class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                        >
                            <option v-for="opcao in opcoesFaixaetaria" :value="opcao">{{ opcao }}</option>
                        </select>
                        <InputError class="tw-mt-2" :message="form.errors.faixa_etaria" />
                    </div>
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="vagas" value="Vagas" required/>
                        <input id="vagas" type="number" required autofocus autocomplete="vagas"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.vagas"
                        />
                        <InputError class="tw-mt-2" :message="form.errors.vagas" />
                    </div> 
                </div>
    
                <!-- Resumo -->
                <div class="tw-flex tw-flex-col tw-gap-2 tw-m-2">
                    <InputLabel for="resumo" value="Resumo" required/>
                    <textarea v-model="form.resumo" rows="4" class="tw-mt-1 tw-text-gray-700  tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm">
                    </textarea>
                </div>
    
                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <p class="tw-font-semibold tw-flex tw-flex-1 tw-text-green-800 tw-text-lg tw-font-title tw-my-4">DATA E HORA</p>
                </div>
                <hr>
    
                <div class="tw-flex tw-flex-row tw-mt-8 md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <div class="tw-flex tw-flex-auto tw-w-80 tw-flex-col">
                        <InputLabel for="dias_semana" value="Dias da Semana" required/>
                        <select
                            v-model="form.dias_semana" id="dias_semana" 
                            class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                        >
                            <option v-for="opcao in opcoesDiasSemana" :value="opcao">{{ opcao }}</option>
                        </select>
                        <InputError class="tw-mt-2" :message="form.errors.dias_semana" />
                    </div>
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="turno" value="Turno" required/>
                        <select
                            v-model="form.turno" id="turno" 
                            class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                        >
                            <option v-for="opcao in opcoesTurno" :value="opcao">{{ opcao }}</option>
                        </select>
                        <InputError class="tw-mt-2" :message="form.errors.turno" />
                    </div>
                    <div class="tw-flex tw-flex-auto tw-w-0 tw-flex-col">
                        <InputLabel for="hora_inicio" value="Hora de Início" required/>
                        <input
                            id="hora_inicio"
                            type="time"  
                            required
                            autofocus
                            autocomplete="hora_inicio"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.hora_inicio"
                        />
                        <InputError class="tw-mt-2" :message="form.errors.hora_inicio" />
                    </div>
                    <div class="tw-flex tw-flex-auto tw-w-0 tw-flex-col">
                        <InputLabel for="hora_termino" value="Hora de Termino" required/>
                        <input
                            id="hora_termino"
                            type="time" 
                            autofocus
                            autocomplete="hora_termino"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.hora_termino" 
                        />
                        <InputError class="tw-mt-2" :message="form.errors.hora_termino" />
                    </div>
                    <div class="tw-flex tw-flex-auto tw-w-0 tw-flex-col">
                        <InputLabel for="hora_termino" value="Hora de Termino" required/>
                        <input
                            id="data_inicio"
                            type="date" 
                            autofocus
                            autocomplete="data_inicio"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.data_inicio" 
                        />
                        <InputError class="tw-mt-2" :message="form.errors.data_inicio" />
                    </div>
                    <!-- <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="data_inicio_inscricao" value="Precisão de Início" required/>
                        <input id="data_inicio_inscricao" type="date" required autofocus autocomplete="data_inicio_inscricao"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.data_inicio_inscricao"
                        />
                        <InputError class="tw-mt-2" :message="form.errors.data_inicio_inscricao" />
                    </div>                    -->
                </div>
                
                <div class="tw-flex tw-justify-end tw-gap-2">
                    <Link :href="route('painel.turmas')" class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-4 tw-border tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-opacity-90 tw-border-primary active:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-primary tw-bg-white tw-items-center ">
                        VOLTAR
                    </Link>
                    <span @click="update()" class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-4 tw-border tw-border-transparent tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-white tw-bg-green-500 tw-items-center ">
                        <Icon icon="fluent:save-16-regular" class="tw-h-6 tw-w-6 tw-text-white tw-mr-2" /> 
                        Salvar
                    </span>
                </div>

            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import { Head, useForm, router, Link} from '@inertiajs/vue3';
import { Notify } from 'quasar';
import { Icon } from '@iconify/vue';

const props = defineProps({
    turma: {
        type: Object,
        default: {}
    },
    cursos: {
        type: Array,
        default: []
    },
    editais: {
        type: Array,
        default: []
    },
})

const form = useForm({
    id: props.turma.id,
    nome: props.turma.nome,
    categoria: props.turma.categoria,
    nivel: props.turma.nivel,
    faixa_etaria: props.turma.faixa_etaria,
    turno: props.turma.turno,
    modalidade: props.turma.modalidade,
    horas_curso: props.turma.horas_curso,
    resumo: props.turma.resumo,
    vagas: props.turma.vagas,
    data_inicio: props.turma.data_inicio,
    dias_semana: props.turma.dias_semana,
    edital_id: props.turma.edital_id,
    curso_id: props.turma.curso_id,
    hora_inicio: props.turma.hora_inicio,
    hora_termino: props.turma.hora_termino,
})

const editaisList = props.editais.map(edital => ({label: edital.nome, value: edital.id}))
const cursosList = props.cursos.map(modelo => ({label: modelo.nome, value: modelo.id}))

const opcoesCategoria = ['Capacitação', 'Qualificação', 'Superior', 'Técnico'];
const opcoesTurno = ['Integral', 'Matutino', 'Vespertino', 'Noturno'];
const opcoesCargahoraria = ['40 Horas','160 Horas','240 Horas', '960 Horas','1440 Horas']
const opcoesModalidade = ['Cadastro de Reserva', 'EAD', 'Online', 'Presencial'];
const opcoesDiasSemana = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sabado','Domingo'];
const opcoesNivel = ['Iniciante','Intermediario','Avançado']
const opcoesFaixaetaria = ['Infantil', 'Infanto-juvenil', 'Adulto']


function update(){
    router.post(route('painel.turmas.update', form.id), {
        _method: 'patch',
        ...form,
    }, {
        preserveScroll: true,
        onSuccess: (res) => {
            form.reset()
            Notify.create({
                message: "Dados do municipio atualizados com sucesso.",
                color: "secondary"
            })
        },
        onError: (err) => {
            Notify.create({
                message: "Não foi possível atualizar os dados do municipio.",
                color: "negative"
            })
        }
    })
}

</script>