<template>
  <Head title="Cursos" />

  <AuthenticatedLayout>
    <div class="tw-flex tw-flex-1 tw-flex-col">
      <div
        class="tw-flex tw-flex-1 tw-flex-col tw-justify-start tw-bg-white tw-shadow sm:tw-rounded-lg tw-px-8 tw-py-4 tw-overflow-hidden tw-overflow-y-scroll"
      >
        <div
          class="tw-flex md:tw-flex-row tw-flex-col tw-gap-4 tw-py-4 tw-items-center tw-justify-between items tw-border-b-2 tw-border-gray-200"
        >
          <h4 class="tw-font-title tw-font-semibold">
            Adicionar Curso
          </h4>
        </div>
        <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
          <p class="tw-flex tw-flex-1 tw-text-green-800 tw-text-lg tw-font-title tw-my-4">
            INFORMAÇÕES SOBRE O CURSO
          </p>
        </div>
        <!-- Nome, Situação e Destaque -->
        <div
          class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2"
        >
          <!-- <div class="tw-flex tw-flex-1 tw-flex-col">imagem</div> -->
          <div class="tw-flex tw-flex-2 tw-flex-col">
            <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
              <div  class="tw-flex tw-flex-row tw-flex-1 tw-gap-2 tw-items-start">
                <div class="q-file-image">
                    <q-file
                    disable
                        outlined
                        :model-value="form.imagem"
                        @update:model-value="updateFile"
                        accept=".jpg,.png"
                        >
                        <template v-slot:before>
                        <div
                            class="q-file-image-preview"
                            :style="getImagePreviewStyle"
                        >
                            <img :src="srcImage || defaultImage" />
                        </div>
                        </template>
                    </q-file>
                  </div>
                </div>
              <div class="tw-flex tw-flex-row tw-flex-1"></div>
            </div>
          </div>
          <div class="tw-flex tw-flex-auto tw-flex-col">
            <div class="tw-flex tw-flex-row tw-justify-between">
              <!-- Nova div para "Nome do Curso" e "Status" -->
              <div class="tw-flex tw-flex-col tw-mr-4 tw-w-3/4">
                <!-- Campo "Nome do Curso" com largura de 75% -->
                <InputLabel for="nome" value="Nome do Curso" required />
                <q-input
                  id="nome"
                  v-model="form.nome"
                  type="text"
                  outlined
                  class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                disable />
                <InputError class="tw-mt-2" :message="form.errors.nome" />
              </div>

              <div class="tw-flex tw-flex-col tw-w-1/4">
                <!-- Campo "Status" com largura de 25% -->
                <InputLabel for="situacao" value="Status" required />
                <q-select
                  id="situacao"
                  v-model="form.situacao"
                  outlined
                  class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                disable />
                <InputError class="tw-mt-2" :message="form.errors.situacao" />
              </div>
            </div>

            <div class="tw-flex tw-flex-auto tw-flex-col tw-mt-4">
              <!-- Campo "Destaque" abaixo dos campos anteriores -->
              <InputLabel for="destaque" value="Destaque" required />
              <div class="tw-flex tw-flex-row">
                <!-- Adicione esta div para alinhar os radio buttons lado a lado -->
                <q-radio v-model="form.destaque" val="Sim" label="Sim" disable />
                <q-radio v-model="form.destaque" val="Nao" label="Não" disable />
              </div>
              <InputError class="tw-mt-2" :message="form.errors.destaque" />
            </div>

            <div class="tw-flex tw-flex-auto tw-flex-col tw-mt-4">
              <!-- Campo "Destaque" abaixo dos campos anteriores -->
              <InputLabel
                for="link_video_apresentacao"
                value="Link do Vídeo sobre o Curso"
                required
              />
              <q-input
                id="link_video_apresentacao"
                outlined
                class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                v-model="form.link_video_apresentacao"
                type="text"
              disable />
              <InputError
                class="tw-mt-2"
                :message="form.errors.link_video_apresentacao"
              />
            </div>
          </div>
        </div>
        <br />
        <div
          class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2"
        >
          <p
            class="tw-flex tw-flex-1 tw-text-green-800 tw-text-lg tw-font-title tw-my-4"
          >
            INFORMAÇÕES COMPLEMENTARES
          </p>
        </div>
        <div class="tw-flex tw-flex-col tw-gap-2 tw-m-2">
          <InputLabel for="tags" value="Tags" required />
          <q-select
            multiple
            v-model="tag"
            outlined
            class="tw-mt-1 tw-text-gray-700 tw-bg-white-50 tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
            placeholder="Busque pela Tag"
          disable />
          <InputError class="tw-mt-2" :message="form.errors.tag" />
        </div>
        <!-- Resumo -->
        <div class="tw-flex tw-flex-col tw-gap-2 tw-m-2">
          <InputLabel for="resumo" value="Descrição" required />
          <q-input
            outlined
            rows="4"
            class="tw-mt-1 tw-text-gray-700 tw-bg-white-50 tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
            v-model="form.descricao"
            type="textarea"
          disable />
        </div>

        <!-- Conteúdo Programático -->
        <div class="tw-flex tw-flex-col tw-gap-2 tw-m-2">
          <InputLabel
            for="conteudo_programatico"
            value="Conteúdo Programático"
            required
          />
          <q-input
            outlined
            rows="4"
            class="tw-mt-1 tw-text-gray-700 tw-bg-white-50 tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-smauto-upload"
            v-model="form.conteudo_programatico"
            type="textarea"
          disable />
        </div>

        <!-- Objetivos -->
        <div class="tw-flex tw-flex-col tw-gap-2 tw-m-2">
          <InputLabel for="objetivos" value="Objetivos" required />
          <q-input
            outlined
            rows="4"
            class="tw-mt-1 tw-text-gray-700 tw-bg-white-50 tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
            v-model="form.objetivos"
            type="textarea"
          disable />
        </div>
        <!-- Campo de Atuação -->
        <div class="tw-flex tw-flex-col tw-gap-2 tw-m-2 tw-mb-10">
          <InputLabel for="campo_atuacao" value="Área de Atuação" required />
          <q-input
            outlined
            rows="4"
            class="tw-mt-1 tw-text-gray-700 tw-bg-white-50 tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
            v-model="form.campo_atuacao"
            type="textarea"
          disable />
        </div>

        <div class="tw-flex tw-justify-end tw-gap-2">
          <Link :href="route('painel.cursos')"
            class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-4 tw-border tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-opacity-90 tw-border-primary active:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-primary tw-bg-white tw-items-center ">
          VOLTAR
          </Link>
          <Link :href="route('painel.cursos.editar', props.curso.id)"
            class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-4 tw-border tw-border-transparent tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-white tw-bg-green-500 tw-items-center ">
          Editar
          </Link>
        </div>
      </div>
    </div>
  </AuthenticatedLayout>
</template>
<script setup>
import InputError from "@/Components/InputError.vue";
import InputLabel from "@/Components/InputLabel.vue";
import PrimaryButton from "@/Components/PrimaryButton.vue";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout.vue";
import { Icon } from "@iconify/vue";
import { Head, useForm, router, Link } from "@inertiajs/vue3";
import { Notify } from "quasar";
import { onMounted } from "vue";
import { ref, computed } from "vue";

const props = defineProps({
  turmas: {
    type: Array,
    default: [],
  },
  curso: {
    type: Object,
    default: {},
  },
});

const defaultImage = ref(
  "https://t4.ftcdn.net/jpg/04/73/25/49/360_F_473254957_bxG9yf4ly7OBO5I0O5KABlN930GwaMQz.jpg"
);

const srcImage = ref(null);

const toBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

const updateFile = async (event) => {
  srcImage.value = await toBase64(event);
  form.imagem = event
};

const getImagePreviewStyle = computed(() => {
  let url = srcImage.value || defaultImage.value;
  return `background-image: url(${url})`;`/storage/${col.value}`
});

const tag = props.curso.tag;

const form = useForm({
  id: props.curso.id,
  nome: props.curso.nome,
  situacao: props.curso.situacao,
  link_video_apresentacao: props.curso.link_video_apresentacao,
  campo_atuacao: props.curso.campo_atuacao,
  objetivos: props.curso.objetivos,
  conteudo_programatico: props.curso.conteudo_programatico,
  descricao: props.curso.descricao,
  destaque: props.curso.destaque,
});
</script>

<style>
.custom-uploader {
  max-width: 800px;
  /* Ajuste o valor conforme necessário */
  /* Outros estilos personalizados, se necessário */
}

.q-file-image {
  width: 500px;
  position: relative;
  height: 250px;
  overflow: hidden;
  border-radius: 4px;
}
.q-file-image .q-field {
  padding: 0;
  border: 0 none;
}
.q-file-image .q-field .q-field__before,
.q-file-image .q-field .q-field__inner,
.q-file-image .q-field .q-field__control,
.q-file-image .q-field .q-field__control-container,
.q-file-image .q-field .q-field__native,
.q-file-image .q-field .q-field__input,
.q-file-image .q-field .q-field__control:before {
  margin: 0 !important;
  padding: 0 !important;
  border: 0 none !important;
  box-shadow: none !important;
  border-radius: 0;
}
.q-file-image .q-field .q-field__control,
.q-file-image .q-field .q-field__native {
  height: 250px;
}
.q-file-image .q-file-image-preview {
  position: absolute;
  left: 0;
  top: 0;
  height: 250px;
  width: 100%;
}
.q-file-image .q-file-image-preview img {
  display: block;
  width: 100%;
  object-fit: cover;
  border-radius: 4px;
}
.q-file-image .q-file-image-preview {
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center center;
}
</style>