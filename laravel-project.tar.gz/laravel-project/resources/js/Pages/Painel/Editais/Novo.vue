<template>
    <Head title="Editais" />

    <AuthenticatedLayout>
        <div class="tw-flex tw-flex-1 tw-flex-col">
            <div
                class="tw-flex tw-flex-1 tw-flex-col tw-justify-start tw-bg-white tw-shadow sm:tw-rounded-lg tw-px-8 tw-py-4 tw-overflow-hidden tw-overflow-y-scroll">
                <div
                    class="tw-flex md:tw-flex-row tw-flex-col tw-gap-4 tw-py-4 tw-items-center tw-justify-between items tw-border-b-2 tw-border-gray-200">
                    <h4 class="tw-text-navy-500 tw-font-title tw-font-semibold">Adicionar Edital</h4>
                    <div class="tw-flex tw-gap-6">
                        <Link v-if="props.anterior != null" :href="route('painel.editais.editar', props.anterior)"
                            class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-2 tw-gap-4 tw-border tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-opacity-90 tw-border-navy-500 active:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-navy-500 tw-bg-white tw-items-center ">
                        <Icon icon="icons8:left-round" class="tw-h-8 tw-w-8 tw-text-navy-500" />
                        ANTERIOR
                        </Link>
                        <Link v-if="props.proximo != null" :href="route('painel.editais.editar', props.proximo)"
                            class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-2 tw-gap-4 tw-border tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-opacity-90 tw-border-navy-500 active:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-white tw-bg-navy-500 tw-items-center ">
                        PRÓXIMO
                        <Icon icon="icons8:right-round" class="tw-h-8 tw-w-8 tw-text-white" />
                        </Link>
                    </div>
                </div>

                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <p class="tw-flex tw-flex-1 tw-text-green-800 tw-text-lg tw-font-title tw-my-4"
                        style="border-bottom: 2px solid #ccc">INFORMAÇÕES BÁSICAS</p>
                </div>

                <!-- Linha 01 -->
                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <div class="tw-flex tw-flex-col">
                        <InputLabel for="dt_publicacao" value="Data de Publicação" required />
                        <q-input outlined id="dt_publicacao" type="date" required autofocus autocomplete="dt_publicacao"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.dt_publicacao" />
                        <InputError class="tw-mt-2" :message="form.errors.dt_publicacao" />
                        <div class="tw-flex tw-flex-auto tw-flex-col tw-mt-4">
                            <!-- Campo "Destaque" abaixo dos campos anteriores -->
                            <InputLabel for="agendar_publicacao" value="Agendar Publicação" required />
                            <div class="tw-flex tw-flex-row">
                                <!-- Adicione esta div para alinhar os radio buttons lado a lado -->
                                <q-radio v-model="form.agendar_publicacao" val="Sim" label="Sim" />
                                <q-radio v-model="form.agendar_publicacao" val="Nao" label="Não"/>
                            </div>
                            <InputError class="tw-mt-2" :message="form.errors.destaque" />
                        </div>
                    </div>

                    <div class="tw-flex tw-flex-col">
                        <InputLabel for="dt_fim_edital" value="Fim do Edital" required />
                        <q-input outlined id="dt_fim_edital" type="date" required autofocus autocomplete="dt_fim_edital"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.dt_fim_edital" />
                        <InputError class="tw-mt-2" :message="form.errors.dt_fim_edital" />
                    </div>
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="numero_edital" value="Numero do Edital" required />
                        <q-input outlined label="Digite o Numero do Edital" v-model="form.numero_edital"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm" />
                        <InputError class="tw-mt-2" :message="form.errors.numero_edital" />
                    </div>
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="situacao" value="Status" required />
                        <q-select outlined readonly v-model="form.situacao" :options="opcoesStatus"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm" />
                        <InputError class="tw-mt-2" :message="form.errors.situacao" />

                    </div>
                </div>

                <!-- Linha 02 -->
                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
					<div class="tw-flex tw-flex-col">
						<InputLabel for="dt_inicio_inscricao" value="Início da Inscrição" required />
						<q-input 
							outlined 
							id="dt_inicio_inscricao" 
							type="date" 
							required 
							autofocus
							autocomplete="dt_inicio_inscricao"
							class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
							v-model="form.dt_inicio_inscricao" />
						<InputError class="tw-mt-2" :message="form.errors.dt_inicio_inscricao" />
					</div>
					<div class="tw-flex tw-flex-col">
						<InputLabel for="dt_fim_inscricao" value="Término da Inscrição" required />
						<q-input 
							outlined 
							id="dt_fim_inscricao" 
							type="date" 
							required 
							autofocus
							autocomplete="dt_fim_inscricao"
							class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
							v-model="form.dt_fim_inscricao" />
						<InputError class="tw-mt-2" :message="form.errors.dt_fim_inscricao" />
					</div>
					<div class="tw-flex tw-flex-1 tw-flex-col">
						<InputLabel for="escola_id" value="Escolas" required />
						<q-select 
							id="escola_id"
							outlined
							map-options
							emit-value
							v-model="form.escola_id" 
							:options="opcoesEscola"
                            label="Selecione a Escola"
							class="tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm" 
							@update:modelValue="updateMunicipioBasedOnEscola" />
						<InputError class="tw-mt-2" :message="form.errors.escola_id" />
						<div class="tw-flex tw-flex-auto tw-flex-col tw-mt-4">
							<!-- Campo "Destaque" abaixo dos campos anteriores -->
							<InputLabel 
							for="udepi" value="UDEPI?" required />
							<div class="tw-flex tw-flex-row">
								<!-- Adicione esta div para alinhar os radio buttons lado a lado -->
								<q-radio v-model="form.udepi" val="Sim" label="Sim" @update:modelValue="enableUdepiField('Sim')" />
  								<q-radio v-model="form.udepi" val="Nao" label="Não" @update:modelValue="enableUdepiField('Nao')" />
							</div>
							<InputError class="tw-mt-2" :message="form.errors.destaque" />
						</div>
					</div>
					<div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="municipio_id" value="Municipios" required />
                        <q-select 
                            id="municipio_id" 
                            outlined 
                            map-options emit-value 
                            v-model="form.municipio_id"
                            :options="opcoesMunicipio" 
                            label="Selecione a Escola primeiro"
                            class="tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm" :readonly="form.udepi === 'Nao' || form.udepi === ''"/>
                        <InputError class="tw-mt-2" :message="form.errors.municipio_id" />
                    </div>
				</div>
                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <p class="tw-flex tw-flex-1 tw-text-green-800 tw-text-lg tw-font-title tw-my-4">Documentação Exigida</p>
                </div>
                <div class="tw-flex tw-flex-col tw-gap-2 tw-m-2">
                    <InputLabel for="documentos_necessarios" value="Documentação Exigida" required />
                    <q-select
						use-chips
                        multiple
                        outlined 
                        v-model="form.documentos_necessarios" 
                        :options="opcoesDocumentos" 
                        label="Selecione os Documentos exigidos"
                        class="tw-mt-1 tw-text-gray-700 tw-bg-white-50 tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm">
                    </q-select>
                </div>
                <div class="tw-flex tw-justify-end tw-gap-2">
                    <Link :href="route('painel.editais')"
                        class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-4 tw-border tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-opacity-90 tw-border-primary active:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-primary tw-bg-white tw-items-center ">
                    CANCELAR
                    </Link>
                    <span @click="store()"
                        class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-4 tw-border tw-border-transparent tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-white tw-bg-green-500 tw-items-center ">
                        <Icon icon="fluent:save-16-regular" class="tw-h-6 tw-w-6 tw-text-white tw-mr-2" />
                        PRÓXIMO
                    </span>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Icon } from '@iconify/vue';
import { Head, useForm, router, Link } from '@inertiajs/vue3';
import { Notify } from 'quasar';
import { onMounted } from 'vue';
import { ref, computed, watch } from 'vue';


const props = defineProps({
    escolas: {
        type: Array,
        default: []
    },
    tiposArquivo: {
        type: Array,
        default: []
    },

    editais: {
        type: Array,
        default: []
    },
    turmas: {
        type: Array,
        default: [],
    },

    municipios: {
        type: Array,
        default: [],
    },
    cursos: {
        type: Array,
        default: [],
    }
})

const agendar_publicacao = ref("");
const udepi = ref("");
const selectedCourseId = ref(null);

const opcoesEscola = props.escolas.map(escola => ({ label: escola.nome, value: escola.id }))
const opcoesMunicipio = props.municipios.map(municipio => ({ label: municipio.nome, value: municipio.id }))

const opcoesStatus = ['Ativo', 'Inativo', 'Bloqueado']
const opcoesDocumentos = ['Comprovante de Endereço', 'RG/CPF', 'Titulo de Eleitor', 'Comprovante de Escolaridade'];

const form = useForm({
    numero_edital: '',
    dt_publicacao: '',
    dt_fim_edital: '',
    escola_id: '',
    agendar_publicacao: '',
    dt_inicio_inscricao: '',
    dt_fim_inscricao: '',
    situacao: '',
    municipio_id: '',
    udepi: '',
    documentos_necessarios: [],
    turma_id: ''
})

function store() {

    form.post(route('painel.editais.store'), {
        preserveScroll: true,
        forceFormData: true,
        onSuccess: (res) => {
            form.reset()
            Notify.create({
                message: "Edital registrado com sucesso.",
                color: "secondary"
            })
        },
        onError: (err) => {
            console.log(err)
            Notify.create({
                message: "Não foi possível registrar o Edital.",
                color: "negative"
            })
        }
    })
}

// Modal para vinculação de Turmas em um edital

const filtersModal = ref(false)

const busca = ref('')
const initialPagination = ref({
    sortBy: 'desc',
    descending: false,
    page: 1,
    rowsPerPage: 10
})

const rowsSelected = ref([])

const dateFormatOptions = {
    year: "numeric", month: "numeric", day: "numeric"
}

function closeModal() {
    filtersModal.value = false
}

const columns = [
    { name: 'id', field: 'id', label: 'ID', required: true, align: 'left', sortable: true },
    //format: val => `${val.id} EDITAL - ${val.nome}`
    { name: 'turma', field: 'nome', label: 'TURMA', align: 'left', sortable: true },
    { name: 'vagas', field: 'vagas', label: 'VAGAS', align: 'left', sortable: true },
    { name: 'status', field: 'situacao', label: 'STATUS', align: 'left', sortable: true },
    { name: 'actions', label: 'AÇÕES', align: 'center', field: 'id' },
]

const visibleColumns = [
    'id',
    'turma',
    'vagas',
    'status',
    'actions',
]

//
const filtroTipo = ref([])
const filtroStatus = ref([])
const filtroModalidade = ref([])
const filtroNivel = ref([])
const filtroTurno = ref([])
const filtroSituacao = ref([])
const filtroCargaHoraria = ref([])
const filtroCurso = ref([])
const filtroEdital = ref([])
const municipioId = ref(null);
const filteredTurmas = ref(props.turmas)

//
const chipCategoria = computed(() => filtroTipo.value.length > 0)
const chipStatus = computed(() => filtroStatus.value.length > 0)
const chipModalidade = computed(() => filtroModalidade.value.length > 0)
const chipNivel = computed(() => filtroNivel.value.length > 0)
const chipCargaHoraria = computed(() => filtroCargaHoraria.value.length > 0)
const chipTurno = computed(() => filtroTurno.value.length > 0)
const chipSituacao = computed(() => filtroSituacao.value.length > 0)
const chipEdital = computed(() => filtroEdital.value != '')
const chipCurso = computed(() => filtroCurso.value != '')

//
const opcoesNivel = ['Iniciante', 'Intermediario', 'Avançado'];
const opcoesCargaHoraria = ['40 Horas', '160 Horas', '240 Horas', '960 Horas', '1440 Horas']
const opcoesSituacao = ['Ativo', 'Inativo']
const opcoesModalidade = ['Cadastro de Reserva', 'EAD', 'Online', 'Presencial'];
const opcoesTurno = ['Integral', 'Matutino', 'Vespertino', 'Noturno'];
const opcoesCategoria = ['Capacitação', 'Qualificação', 'Superior', 'Técnico'];



function applyFilters() {
    const filtradoCategoria = filtroCategoria.value.length > 0 ? props.turmas.filter(turma => filtroCategoria.value.includes(turma.categoria)) : props.turmas
    const filtradoTipo = filtroTipo.value.length > 0 ? props.turmas.filter(turma => filtroTipo.value.includes(turma.tipo)) : props.turmas
    const filtradoModalidade = filtroModalidade.value.length > 0 ? filtradoEscola.filter(turma => filtroModalidade.value.includes(turma.modalidade)) : filtradoEscola
    const filtradoNivel = filtroNivel.value.length > 0 ? filtradoNivel.filter(turma => filtroNivel.value.includes(turma.nivel)) : filtradoNivel
    const filtradoCargaHoraria = filtroCargaHoraria.value.length > 0 ? filtradoCargaHoraria.filter(turma => filtroCargaHoraria.value.includes(turma.horas_curso)) : filtradoCargaHoraria
    const filtradoTurno = filtroTurno.value.length > 0 ? filtradoModalidade.filter(turma => filtroTurno.value.includes(turma.turno)) : filtradoModalidade
    const filtradoSituacao = filtroSituacao.value.length > 0 ? filtradoTurno.filter(turma => filtroSituacao.value.includes(edital.situacao)) : filtradoTurno
    const filtradoEdital = filtroEdital.value != '' ? filtradoSituacao.filter(turma => turma.edital_id == filtroEdital) : filtradoSituacao
    const filtradoCurso = filtroCurso.value != '' ? filtradoSituacao.filter(turma => turma.curso_id == filtroCurso) : filtradoSituacao
    const filtradoStatus = filtroStatus.value != '' ? filtradoStatus.filter(turma => turma.edital_id == filtroEdital) : filtradoStatus

    filteredTurmas.value = filtradoEdital
    filtersModal.value = false
}

function removeFilterNivel() {
    filtroNivel.value = []
    applyFilters()
}
function removeFilterCargaHoraria() {
    filtroCargaHoraria.value = []
    applyFilters()
}
function removeFilterStatus() {
    filtroStatus.value = []
    applyFilters()
}
function removeFilterSituacao() {
    filtroSituacao.value = []
    applyFilters()
}
function removeFilterModalidade() {
    filtroModalidade.value = []
    applyFilters()
}
function removeFilterTurno() {
    filtroTurno.value = []
    applyFilters()
}
function removeFilterEdital() {
    filtroEdital.value = ''
    applyFilters()
}

function removeFilterCurso() {
    filtroCurso.value = ''
    applyFilters()
}

function clearFilters() {
    filtroCargaHoraria.value = []
    filtroNivel.value = []
    filtroStatus.value = []
    filtroTipo.value = []
    filtroModalidade.value = []
    filtroTurno.value = []
    filtroSituacao.value = []
    filtroEdital.value = []
    filtroCurso.value = []
}

//Exportar CSV
const exportToCSV = () => {
    // Dados da tabela
    const columns = [
        'ID',
        'Turma',
        'Vagas',
        'Status',
    ];

    const data = filteredTurmas.value.map((turma) => [
        turma.id,
        turma.nome,
        turma.vagas,
        turma.situacao,
    ]);

    // Preparar os dados para exportação CSV
    const csvContent = `${columns.join(',')}\n${data.map((row) => row.join(',')).join('\n')}`;

    // Criar um objeto Blob para o conteúdo CSV
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });

    // Criar um URL para o Blob
    const url = window.URL.createObjectURL(blob);

    // Criar um link de download
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'turmas.csv');
    document.body.appendChild(link);

    // Clicar no link para iniciar o download
    link.click();

    // Limpar o link e revogar o objeto URL
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
};


watch(
  () => form.udepi,
  (newValue) => {
    if (newValue !== 'Sim') {
        if (municipioId.value !== null) {
        form.municipio_id = municipioId.value;
      }
    }
  }
);

watch(
    () => [form.dt_publicacao, form.dt_fim_edital],
    ([publicacao, fimEdital]) => {
        const currentDate = new Date();
        const editalStartDate = new Date(publicacao);
        const editalEndDate = new Date(fimEdital);

        // Verifique se a data atual está entre dt_publicacao e dt_fim_edital
        if (editalStartDate <= currentDate && currentDate <= editalEndDate) {
            form.situacao = 'Ativo';
        } else {
            form.situacao = 'Inativo';
        }
    }
);

// Função para atualizar o campo "Município" com base na seleção da "Escola"
function updateMunicipioBasedOnEscola() {
  // Verifica se foi selecionada uma escola
  if (form.escola_id !== null) {
    // Atribui o valor do município da escola selecionada ao campo "Município"
    form.municipio_id = props.escolas.find((escola) => escola.id === form.escola_id)?.municipio_id;
  } else {
    // Se nenhuma escola foi selecionada, defina o campo "Município" como nulo
    form.municipio_id = null;
  }
}

function enableUdepiField(value) {
  if (value === 'Sim') {
    // Quando "Sim" é selecionado, salve o valor atual de municipio_id
    municipioId.value = form.municipio_id;
  } else if (value === 'Nao') {
    // Quando "Não" é selecionado, restaure o valor de municipio_id
    form.municipio_id = municipioId.value;
  }
}

</script>

