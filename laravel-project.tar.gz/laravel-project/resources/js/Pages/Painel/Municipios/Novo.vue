<template>
    <Head title="Municipios" />
    
    <AuthenticatedLayout>
    
        <div class="tw-flex tw-flex-1 tw-flex-col">
            <div class="tw-flex tw-flex-1 tw-flex-col tw-justify-start tw-bg-white tw-shadow sm:tw-rounded-lg tw-px-8 tw-py-4">
                <div class="tw-flex md:tw-flex-row tw-flex-col tw-gap-4 tw-py-4 tw-items-center tw-justify-between items tw-border-b-2 tw-border-gray-200">
                    <h4 class="tw-font-title tw-font-semibold">Adicionar Município</h4>
                </div>
                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <p class="tw-flex tw-flex-1 tw-text-green-800 tw-text-lg tw-font-title tw-my-4">INFORMAÇÕES BÁSICAS</p>
                </div>
                <div class="tw-flex md:tw-flex-row tw-flex-col md:tw-gap-10 tw-gap-2 tw-m-2">
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="nome" value="Uf" required/>
                        <q-select
                            id="uf"
                            :options="opcaoUf"
                            map-options
                            emit-value
                            outlined 
                            required 
                            autofocus 
                            autocomplete="uf"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.uf"
                            @blur="buscarEnderecoPorCEP" />
                        <InputError class="tw-mt-2" :message="form.errors.nome" />
                    </div>
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="uf" value="Municipio" required/>
                        <q-select
                            id="nome"
                            map-options
                            emit-value
                            outlined
                            required
                            autofocus
                            autocomplete="nome"
                            class="tw-mt-1 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-500 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"
                            v-model="form.nome"
                            :options="opcoesMunicipios" />
                        <InputError class="tw-mt-2" :message="form.errors.nome" />
                    </div>
                    <div class="tw-flex tw-flex-1 tw-flex-col">
                        <InputLabel for="situacao" value="Situação" required/>
                        <q-select
                            :options="opcaoStatus"
                            outlined
                            v-model="form.situacao" 
                            id="situacao" 
                            class="tw-mt-1 tw-text-gray-700 tw-h-[52px] tw-block tw-w-full tw-border-gray-200 focus:tw-border-gray-200 focus:tw-ring-0 tw-rounded-lg tw-shadow-sm"/>
                        <InputError class="tw-mt-2" :message="form.errors.situacao" />
                    </div>
                </div>
                <br/>
                <div class="tw-flex tw-justify-end tw-gap-2">
                    <Link :href="route('painel.municipios')" class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-4 tw-border tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-opacity-90 tw-border-primary active:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-primary tw-bg-white tw-items-center ">
                        CANCELAR
                    </Link>
                    <span @click="store()" class="tw-inline-flex tw-cursor-pointer tw-px-8 tw-py-4 tw-border tw-border-transparent tw-rounded-md tw-font-body tw-font-semibold tw-text-base tw-uppercase hover:tw-bg-opacity-90 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-indigo-500 focus:tw-ring-offset-2 tw-transition tw-ease-in-out tw-duration-150 tw-text-white tw-bg-green-500 tw-items-center ">
                        <Icon icon="fluent:save-16-regular" class="tw-h-6 tw-w-6 tw-text-white tw-mr-2" /> 
                        Salvar
                    </span>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import PrimaryButton from '@/Components/PrimaryButton.vue';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import { Head, useForm, router, Link} from '@inertiajs/vue3';
import { Notify } from 'quasar';
import { Icon } from '@iconify/vue';
import { ref } from 'vue';

const form = useForm({
    nome: '',
    uf: '',
    situacao: '',
})

const opcoesMunicipios = ref([]);
const opcaoStatus = ['Ativo', 'Bloqueado', 'Inativo']

const opcoesTags = [
    { label: "Ativo", value: "" },
    { label: "Inativo", value: "Inativo" },
    { label: "Bloqueado", value: "Bloqueado" },
];
const opcaoUf = [
	{	label: "Rondônia", value: "11"  },
	{	label: "Acre", value: "12"  },
	{	label: "Amazonas", value: "13"  },
	{	label: "Roraima", value: "14"   },
	{	label: "Pará", value: "15"  },
	{	label: "Amapá", value: "16" },
	{	label: "Tocantins", value: "17" },
	{	label: "Maranhão", value: "21"  },
	{	label: "Piauí", value: "22" },
	{	label: "Ceará", value: "23" },
	{	label: "Rio Grande do Norte", value: "24"   },
	{	label: "Paraíba", value: "25"   },
	{	label: "Pernambuco", value: "26"    },
	{	label: "Alagoas", value: "27"   },
	{	label: "Sergipe", value: "28"   },
	{	label: "Bahia", value: "29" },
	{	label: "Minas Gerais", value: "31"  },
	{	label: "Espírito Santo", value: "32"    },
	{	label: "Rio de Janeiro", value: "33"    },
	{	label: "São Paulo", value: "35" },
	{	label: "Paraná", value: "41" },
	{	label: "Santa Catarina", value: "42"    },
	{	label: "Rio Grande do Sul", value: "43"  },
	{   label: "Mato Grosso do Sul", value: "50"    },
	{   label: "Mato Grosso", value: "51"   },
	{   label: "Goiás", value: "52" },
	{   label: "Distrito Federal", value: "53"  }
]
function store(){
    
    form.post(route('painel.municipios.store'), {
        preserveScroll: true,
        onSuccess: (res) => {
            form.reset()
            Notify.create({
                message: "Municipio registrado com sucesso.",
                color: "secondary"
            })
        },
        onError: (err) => {
            console.log(err)
            Notify.create({
                message: "Não foi possível registrar o Municipio.",
                color: "negative"
            })
        }
    })
}

async function buscarEnderecoPorCEP() {
    const uf = form.uf;
    
    if (uf.length === 2) { // Certifique-se de que a UF tenha dois caracteres, por exemplo, "SP".
        try {
            const response = await axios.get(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${uf}/municipios`);
            const municipios = response.data;

            if (Array.isArray(municipios)) {
                // Mapeie os objetos de município para obter apenas os nomes.
                const nomesMunicipios = municipios.map((municipio) => municipio.nome);

                // Atualize as opções do select de municípios com base nos nomes.
                opcoesMunicipios.value = nomesMunicipios;
            } else {
                console.error('Nenhum município encontrado para esta UF.');
            }
        } catch (error) {
            console.error('Erro ao buscar municípios:', error);
        }
    }
}

</script>


