<script setup>
import PrimaryButton from '@/Components/PrimaryButton.vue';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, usePage } from '@inertiajs/vue3';
import { computed, ref } from 'vue';

const page = usePage();
const user = computed(() => page.props.auth.user)
const boasVindas = ref(true)


</script>

<template>
    <Head title="Inicio" />
    <q-dialog v-model="boasVindas">
        <div class="tw-flex tw-flex-1 tw-p-20 tw-flex-col tw-bg-white tw-rounded-2xl tw-justify-center tw-items-center tw-shadow-md">
            <div class="tw-overflow-hidden tw-justify-center tw-text-center tw-gap-6 tw-flex tw-flex-1 tw-flex-col">
                <h2 class="tw-font-body tw-font-bold tw-text-xl tw-text-primary">Bem vindo(a), {{ user.name }}, à Escola do Futuro de Goiás</h2>
                <h5 class="tw-font-body tw-font-normal tw-text-base tw-text-gray-500">
                    Esta plataforma é dedicada aos alunos da Escola do Futuro de Goiás. Aqui, você terá acesso a informações sobre os cursos disponíveis, em andamento, novos cursos, certificados e outras funcionalidades.
                </h5>  
                <h5 class="tw-font-body tw-font-normal tw-text-base tw-text-gray-500">
                    Você já deu o primeiro passo rumo ao aprendizado e agora pode escolher um curso disponível para se qualificar no mercado de trabalho.
                </h5>  
                <h3 class="tw-font-body tw-font-bold tw-text-base tw-text-gray-700">
                    Antes disso, precisamos de algumas informações adicionais sobre você. Vamos começar?
                </h3>
                <div class="tw-flex tw-flex-1 tw-flex-col tw-justify-center tw-items-center tw-gap-4 lg:tw-flex-row tw-pt-5">
                    <span @click="boasVindas = !boasVindas" class="tw-cursor-pointer tw-max-h-[50px] tw-items-center tw-flex-1 tw-p-3 tw-text-green-600 tw-text-base tw-uppercase tw-rounded-md tw-font-title tw-font-semibold tw-bg-white tw-border-2 tw-border-primary tw-justify-center">
                        FECHAR
                    </span>
                    <PrimaryButton class="tw-max-h-[50px] tw-flex-1 tw-items-center tw-bg-green-600 tw-py-3 tw-text-white tw-justify-center">
                        VAMOS LÁ
                    </PrimaryButton>
                </div>
                
            </div>
        </div>
    </q-dialog>
    <AuthenticatedLayout :props="page.props.auth.user">
        <div class="tw-flex tw-flex-1 tw-p-4 tw-flex-col tw-bg-white tw-rounded-lg tw-justify-center tw-items-center tw-shadow-md">
            <div class="tw-overflow-hidden tw-justify-center tw-text-center tw-gap-1">
                <h2 class="tw-font-title tw-font-bold tw-text-4xl tw-text-gray-700">Olá, {{ user.name }}. Seja bem vindo(a)!</h2>
                <h5 class="tw-font-body tw-font-normal tw-text-2xl tw-text-gray-500">Acesse as nossas funcionalidades pelo menu lateral, em caso de dúvidas clique aqui.</h5>   
                <img src="./../../../imgs/img-dashboard.png" alt="Content">
            </div>
        </div>
    </AuthenticatedLayout>
</template>
