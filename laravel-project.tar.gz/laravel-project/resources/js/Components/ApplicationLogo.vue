<template>
    <img src="./../../imgs/logo-efg.png" class="tw-h-12 tw-w-auto"/>
</template>
