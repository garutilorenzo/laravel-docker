<script setup>
import { Icon } from '@iconify/vue';
import { Link, usePage, router } from '@inertiajs/vue3';
import { defineProps, computed } from 'vue';
const props = defineProps(['user']);
const roles = props.user.roles
const permissions = roles.map(role => role.permissions).flat();
const hasPermission = (permission) => {
  return permissions.some(userPermission => userPermission.name === permission);
};

function logout() {
    router.post(route('logout'))
}

function profile() {
    router.get(route('profile.edit'))
}

function gestao() {
    router.get(route('painel.gestao.usuarios'))
}

function inscricoes(){
    router.get(route('painel.inscricoes'))
}

function escolas(){
    router.get(route('painel.escolas'))
}

function tags(){
    router.get(route('painel.tags'))
}

function municipios(){
    router.get(route('painel.municipios'))
}

function arquivos(){
    router.get(route('painel.tipoarquivo'))
}

function usuarios(){
    router.get(route('painel.gestao.usuarios'))
}

function permissoes(){
    router.get(route('painel.gestao.permissoes'))
}

function niveis(){
    router.get(route('painel.gestao.roles'))
}


</script>
<template>
    <div class="tw-flex tw-flex-row tw-h-16 tw-bg-white tw-justify-end tw-text-gray-700 tw-shadow-md">
        <div class="tw-flex tw-flex- tw-flex-row tw-justify-end" >
            <span class="tw-justify-center tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                <Icon icon="iconoir:bell" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />
            </span>
            <span class="tw-justify-center tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                <Icon icon="iconoir:help-circle" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />
            </span>
            <span @click="profile()"
                class="tw-justify-center tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                <Icon icon="iconoir:profile-circle" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />
            </span>
            <span v-if="hasPermission('Topbar Usuarios') || hasPermission('Topbar Escolas') || hasPermission('Topbar Tags') || hasPermission('Topbar Municipios') || hasPermission('Topbar Arquivos') || hasPermission('Topbar Permissoes') || hasPermission('Topbar Nivel de Acesso')" class="tw-justify-center tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                <Icon icon="ci:settings" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />
                <q-menu transition-show="jump-down" transition-hide="jump-up" style="width:250px">
                    <q-list style="min-width: 150px">
                        <q-item clickable>
                            <q-item-section>
                                <span v-if="hasPermission('Topbar Usuarios')" @click="usuarios()" class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="streamline:interface-user-profile-focus-close-geometric-human-person-profile-focus-user" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Usuarios
                                </span>
                            </q-item-section>
                        </q-item>
                        <q-item clickable>
                            <q-item-section>
                                <span v-if="hasPermission('Topbar Escolas')" @click="escolas()" class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="clarity:building-line" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Escolas
                                </span>
                            </q-item-section>
                        </q-item>
                        <q-item clickable>
                            <q-item-section>
                                <span v-if="hasPermission('Topbar Tags')" @click="tags()" class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="cil:tags" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Tags
                                </span>
                            </q-item-section>
                        </q-item>
                        <q-item clickable>
                            <q-item-section>
                                <span v-if="hasPermission('Topbar Permissoes')" @click="permissoes()"
                                    class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="solar:medal-ribbon-linear" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Permissões
                                </span>
                            </q-item-section>
                        </q-item>
                        <q-item clickable>
                            <q-item-section>
                                <span v-if="hasPermission('Topbar Municipios')" @click="municipios()"
                                    class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="mingcute:building-5-line" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Municipios
                                </span>
                            </q-item-section>
                        </q-item>
                        <q-item clickable>
                            <q-item-section>
                                <span v-if="hasPermission('Topbar Arquivos')" @click="arquivos()"
                                    class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="quill:paper" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Arquivo
                                </span>
                            </q-item-section>
                        </q-item>
                        <q-item clickable>
                            <q-item-section>
                                <span v-if="hasPermission('Topbar Nivel de Acesso')" @click="niveis()"
                                    class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="uil:cell" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Niveis de Acesso
                                </span>
                            </q-item-section>
                        </q-item>
                        <q-item clickable>
                            <q-item-section>
                                <span class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="arcticons:tenbitclockwidget" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Histórico de Logs
                                </span>
                            </q-item-section>
                        </q-item>
                        <q-item clickable>
                            <q-item-section>
                                <span class="tw-justify-right tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                                    <Icon icon="arcticons:password" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />&nbsp;&nbsp;Redefinir Senha
                                </span>
                            </q-item-section>
                        </q-item>
                    </q-list>
                </q-menu>
            </span>
            <span @click="logout()"
                class="tw-justify-center tw-items-center tw-cursor-pointer tw-flex btn-hover tw-shadow-sm tw-py-3 tw-px-4 tw-font-body tw-text-lg tw-border-r-2  tw-border-white tw-leading-5 tw-text-gray-800 border-box focus:tw-outline-none  tw-transition tw-duration-150 tw-ease-in-out">
                <Icon icon="tabler:logout" class="tw-h-[24px] tw-w-[24px] tw-text-gray-600 tw-transition-all" />
            </span>
        </div>
    </div>
</template>