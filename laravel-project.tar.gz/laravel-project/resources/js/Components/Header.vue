<script setup>
import { computed } from 'vue';
import PrimaryButton from './PrimaryButton.vue';

</script>
<template>

  <section class="tw-flex tw-relative tw-flex-1" id="header">
    <div class="tw-flex tw-flex-1 tw-flex-col tw-space-y-6 -tw-mt-8 tw-px-28 tw-py-24 tw-justify-center tw-items-center tw-text-center">
      <h5 class="tw-text-xl tw-font-title tw-font-medium tw-leading-7 tw-text-primary">ESCOLAS DO FUTURO</h5>
      <h4 class="tw-text-6xl tw-font-title tw-font-bold tw-leading-[68px] lg:tw-max-w-2xl tw-text-navy-500 " >A Trilha do seu <span class="tw-text-grass-600">futuro</span><br/> é aqui e <span class="tw-text-grass-600">agora</span>!</h4>
      <p class="tw-text-3xl lg:tw-max-w-5xl tw-text-gray-700 tw-leading-9">A Escola do Futuro nasceu para formar profissionais preparados para o mercado de tecnologia
        e inovação com cursos gratuitos e de qualidade.</p>
        <PrimaryButton class="tw-text-white">VEJA OS CURSOS</PrimaryButton>
    </div>
  </section>

</template>

<style>
  #header {
    background-image: url('./../../imgs/bg-header.png');
    background-size: cover;
    background-position: center;
    object-fit: cover;
    min-height: 30vh;
  }
</style>