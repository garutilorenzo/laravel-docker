<?php

namespace App\Http\Controllers;
use Spatie\Activitylog\Models\Activity;

use Illuminate\Http\Request;

class LogController extends Controller
{
    public function index() {

        $logs = Activity::all();

        return response()->json($logs);
    }
}
