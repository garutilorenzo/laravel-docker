<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Documento;
use Illuminate\Support\Facades\Storage;

class DocumentoController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware(['permission:Index Documentos|Criar Documentos|Editar Documentos|Excluir Documentos|Importar Documentos|Exportar Documentos']);
    // }

    public function store(Request $request) {

        $request->validate([
            'nome' => 'required',
            'situacao' => 'required',
            'data_publicacao' => 'required'
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        $documento = Documento::create([
            'nome' => $request->nome,
            'situacao' => $request->situacao,
            'data_publicacao' => $request->data_publicacao,
            'created_by' => auth()->user()->id,
            'edital_id' => $request->edital_id
        ]);

        if($request->file('arquivo')){
            $pathPdf = Storage::putFile('documentos', $request->file('arquivo'));
            $documento->caminho = $pathPdf;
        }

        $documento->save();
        
        return redirect()->back()->with('response', $documento);
    }
    public function update(Request $request, $id) {
        $request->validate([
            'nome' => 'required',
            'situacao' => 'required',
            'data_publicacao' => 'required'
        ], [
            'required' => 'O campo é obrigatório',
        ]);


        $documento = Documento::find($id);
        $documento->nome = $request->nome;
        $documento->situacao = $request->situacao;
        $documento->data_publicacao = $request->data_publicacao;

        if($request->file('arquivo')){
            $pathPdf = Storage::putFile('documentos', $request->file('arquivo'));
            $documento->caminho = $pathPdf;
        }

        $documento->updated_by = auth()->user()->id;

        $documento->save();

        return redirect()->back()->with('response', $documento);
    }
    public function destroy($id) {
        $documento = Documento::find($id);
        $documento->delete();

        return redirect()->back()->with('response', $documento);
    }
}
