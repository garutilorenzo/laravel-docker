<?php

namespace App\Http\Controllers;

use App\Models\User;
use Inertia\Inertia;
use App\Models\Turma;
use App\Models\Escola;
use App\Models\Inscricao;
use App\Models\Comprovante;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class InscricaoController extends Controller
{

    public function index()
    {
        $inscricoes = Inscricao::with('turma.curso', 'turma.edital.escola', 'criadoPor', 'modificadoPor')->get();
        return Inertia::render('Painel/Inscricoes/Index', [
            'inscricoes' => $inscricoes
        ]);
    }

    public function create()
    {
        $turmas = Turma::all();
        $users = User::all();
        return Inertia::render('Painel/Inscricoes/Novo', [ 'turmas' => $turmas, 'users' => $users]);
    }


    public function edit($id)
    {
        $inscricoes = Inscricao::with('turma', 'comprovantes')->find($id);
        
        $turmas = Turma::where('id', $inscricoes->turma_id)->get();
        return Inertia::render('Painel/Inscricoes/Editar', ['inscricoes' => $inscricoes, 'turmas' => $turmas]);
    }

    public function show($id)
    {
        $inscricoes = Inscricao::with('turma', 'comprovantes')->find($id);
        
        $turmas = Turma::where('id', $inscricoes->turma_id)->get();
        return Inertia::render('Painel/Inscricoes/Detalhes', ['inscricoes' => $inscricoes, 'turmas' => $turmas]);
    }

    public function store(Request $request) {

        $request->validate([
            "nome_completo" => "required",
            "cpf" => "required",
            "data_nascimento" => "required",
            "nome_mae" => "required",
            "telefone" => "required",
            "telefone_alternativo" => "nullable",
            "email" => "required",
            "email_confirmation" => "required",
            "cep" => "required",
            "estado" => "required",
            "municipio" => "required",
            "bairro" => "required",
            "logradouro" => "required",
            "numero" => "required",
            "complemento" => "required",
            "escolaridade" => "required",
            "origem_escolar" => "required",
            "raca" => "required",
            "programa_social" => "nullable",
            "outro_programa_social" => "nullable",
            "nis_pis" => "nullable",
            "deficiencia" => "nullable",
            "outra_deficiencia" => "nullable",
            "como_conheceu" => "nullable",
            "outro_como_conheceu" => "nullable",
            "turma_id" => "required",
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        $inscricao = Inscricao::create([
            'nome_completo' => $request->nome_completo,
            'email' => $request->email,
            'password' => $request->password,
            'cpf' => $request->cpf,
            'tipo' => $request->tipo,
            'rede' => $request->rede,
            'sexo' => $request->sexo,
            'telefone' => $request->telefone,
            'data_nascimento' => $request->data_nascimento,
            'nome_mae' => $request->nome_mae,
            'programa_social' => $request->programa_social,
            'turno' => $request->turno,
            'modalidade' => $request->modalidade,
            'categoria_deficiencia' => $request->categoria_deficiencia,
            'outra_categoria_deficiencia' => $request->outra_categoria_deficiencia,
            'recursos_acessibilidade' => $request->recursos_acessibilidade,
            'como_conheceu' => $request->como_conheceu,
            'tipo_documento' => $request->tipo_documento,
            'escola_id' => $request->escola_id,
            'turma_id' => $request->turma_id,
            'colegio_id' => $request->colegio_id,
        ]);

        return redirect()->back()->with('response', $inscricao);
    }
    
    public function update(Request $request, $id) {
        $request->validate([
            "nome_completo" => "required",
            "cpf" => "required",
            "data_nascimento" => "required",
            "nome_mae" => "required",
            "telefone" => "required",
            "telefone_alternativo" => "nullable",
            "email" => "required",
            "email_confirmation" => "required",
            "cep" => "required",
            "estado" => "required",
            "municipio" => "required",
            "bairro" => "required",
            "logradouro" => "required",
            "numero" => "required",
            "complemento" => "required",
            "escolaridade" => "required",
            "origem_escolar" => "required",
            "raca" => "required",
            "programa_social" => "nullable",
            "outro_programa_social" => "nullable",
            "nis_pis" => "nullable",
            "deficiencia" => "nullable",
            "outra_deficiencia" => "nullable",
            "como_conheceu" => "nullable",
            "outro_como_conheceu" => "nullable",
            "turma_id" => "required",
        ], [
            "required" => 'O campo é obrigatório',
        ]);


        $inscricao = Inscricao::create([
            "nome_completo" => $request->nome_completo,
            "cpf" => $request->cpf,
            "data_nascimento" => $request->data_nascimento,
            "nome_mae" => $request->nome_mae,
            "telefone" => $request->telefone,
            "telefone_alternativo" => $request->telefone_alternativo,
            "email" => $request->email,
            "email_confirmation" => $request->email_confirmation,
            "cep" => $request->cep,
            "estado" => $request->estado,
            "municipio" => $request->municipio,
            "bairro" => $request->bairro,
            "logradouro" => $request->logradouro,
            "numero" => $request->numero,
            "complemento" => $request->complemento || null,
            "escolaridade" => $request->escolaridade,
            "origem_escolar" => $request->origem_escolar,
            "raca" => $request->raca,
            "programa_social" => $request->programa_social || null,
            "outro_programa_social" => $request->outro_programa_social || null,
            "nis_pis" => $request->nis_pis || null,
            "deficiencia" => $request->deficiencia || null,
            "outra_deficiencia" => $request->outra_deficiencia || null,
            "como_conheceu" => $request->como_conheceu || null,
            "outro_como_conheceu" => $request->outro_como_conheceu || null,
            "turma_id" => $request->turma_id,
            "situacao" => "Análise",
        ]);

        foreach($request->arquivos as $arquivo){

            $comprovante = Comprovante::create([
                'tipo_arquivo_id' => $arquivo['tipo_arquivo_id'],
                'situacao' => 'Analise',
                'inscricao_id' => $inscricao->id
            ]);

            if(isset($arquivo['arquivo'])){
                $pathPdf = Storage::putFile('inscricoes/'.$inscricao->id, $arquivo['arquivo']);
                $comprovante->caminho = $pathPdf;
            }

            $comprovante->save();
        }    

        return redirect()->back()->with('response', $inscricao);
    }


    public function destroy(Request $request) {

        $id = $request->id;
        $inscricao = is_array($id) ? Inscricao::destroy($id) : Inscricao::findOrFail($id)->delete();
        return redirect()->route('painel.inscricoes')->with('response', $inscricao);
    }
}
