<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Turma;
use App\Models\Escola;
use App\Models\User;
use App\Models\Comprovante;
use App\Models\Inscricao;
use Illuminate\Support\Facades\Mail;
use Illuminate\Mail\Message;
use Illuminate\Support\Facades\Storage;

class SelecaoController extends Controller
{
    public function index()
    {
        $turmas = Turma::with(['curso', 'edital.escola', 'edital.documentos', 'edital.documentosExigidos'])->get();
        $escolas = Escola::with(['municipio', 'turmas'])->get();
        return Inertia::render('Selecao/Index', ['escolas' => $escolas, 'turmas' => $turmas]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'nome_completo' => 'required',
            'cpf' => 'required',
            'email' => 'required',
            'data_nascimento' => 'required',
            'nome_mae' => 'required',
            'telefone' => 'required',
            'telefone_alternativo' => 'nullable',
            'email' => 'required',
            'email_confirmation' => 'required',
            'cep' => 'required',
            'estado' => 'required',
            'municipio' => 'required',
            'bairro' => 'required',
            'logradouro' => 'required',
            'numero' => 'required',
            'complemento' => 'required',
            'escolaridade' => 'required',
            'origem_escolar' => 'required',
            'raca' => 'required',
            'programa_social' => 'nullable',
            'outro_programa_social' => 'nullable',
            'nis_pis' => 'nullable',
            'deficiencia' => 'nullable',
            'outra_deficiencia' => 'nullable',
            'como_conheceu' => 'nullable',
            'outro_como_conheceu' => 'nullable',
            'turma_id' => 'required',
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        $Users = User::all();
        $emailExistente = false;

        foreach ($Users as $user) {
            if ($request->email === $user->email) {
                $emailExistente = true;
                break; // Se o email existir, não é necessário continuar verificando
            }
        }

        if (!$emailExistente) {
            $usuario = User::create([
                'name' => $request->nome_completo,
                'email' => $request->email,
                'cpf' => $request->cpf,
                'telefone' => $request->telefone,
                'situacao' => 'Ativo',
                'role' => 'Aluno'
            ]);

            $usuario->save();
        }   
       
        
        $inscricao = Inscricao::create([
            'nome_completo' => $request->nome_completo,
            'cpf' => $request->cpf,
            'tipo' => $request->tipo,
            'rede' => $request->rede,
            'data_nascimento' => $request->data_nascimento,
            'nome_mae' => $request->nome_mae,
            'telefone' => $request->telefone,
            'telefone_alternativo' => $request->telefone_alternativo,
            'email' => $request->email,
            'email_confirmation' => $request->email_confirmation,
            'cep' => $request->cep,
            'estado' => $request->estado,
            'municipio' => $request->municipio,
            'bairro' => $request->bairro,
            'logradouro' => $request->logradouro,
            'numero' => $request->numero,
            'complemento' => $request->complemento || null,
            'escolaridade' => $request->escolaridade,
            'origem_escolar' => $request->origem_escolar,
            'raca' => $request->raca,
            'programa_social' => $request->programa_social || null,
            'outro_programa_social' => $request->outro_programa_social || null,
            'nis_pis' => $request->nis_pis || null,
            'deficiencia' => $request->deficiencia || null,
            'outra_deficiencia' => $request->outra_deficiencia || null,
            'como_conheceu' => $request->como_conheceu || null,
            'outro_como_conheceu' => $request->outro_como_conheceu || null,
            'turma_id' => $request->turma_id,
            'situacao' => 'Análise',
        ]);
        
        $inscricao->save();

        $inscricao_id = $inscricao->id;
        if (!empty($request->email)) {
            try {
                $confirmationLink = route('selecao.confirmacao.id', ['inscricao_id' => $inscricao_id]);

                Mail::mailer('smtp')->send([], [], function (Message $message) use ($confirmationLink, $request) {
                    $message->to($request->email)
                        ->subject('Confirmação de Inscrição')
                        ->html("Sua inscrição foi recebida com sucesso. Por favor, clique no link abaixo para confirmar: <a href='{$confirmationLink}'>Confirmar Inscrição</a>");
                });
            } catch (\Exception $e) {
                // dd('Deu erro, o motivo? Não sei', $e);
            }
        }


        return redirect()->back()->with('response', $inscricao);
    }

    public function confirmacao($inscricao_id)
    {
        $inscricao = Inscricao::find($inscricao_id);
        $inscricao->email_verified = '1';
        $inscricao->save();
        return redirect()->route('selecao.confirmacao')->with('response', $inscricao);
    }
}
