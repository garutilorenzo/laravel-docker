<?php

namespace App\Http\Controllers;

use App\Models\Tag;
use Inertia\Inertia;
use App\Models\Curso;
use App\Models\Turma;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CursoController extends Controller
{
    public function __construct()
    {
        $this->middleware(['permission:Index Cursos|Criar Cursos|Editar Cursos|Excluir Cursos|Importar Cursos|Exportar Cursos']);
    }

    public function index()
    {
        $turmas = Turma::get();
        $cursos = Curso::with('criadoPor', 'modificadoPor')->get();
        return Inertia::render('Painel/Cursos/Index', [
            'cursos' => $cursos,
            'turmas' => $turmas
        ]);
    }

    public function create()
    {
        $turmas = Turma::all();
        $tags = Tag::all();
        return Inertia::render('Painel/Cursos/Novo', ['turmas' => $turmas, 'tags' => $tags]);
    }

    public function edit($id)
    {
        $curso = Curso::find($id);
        $turmas = Turma::all();
        $tags = Tag::all();
        return Inertia::render('Painel/Cursos/Editar', ['curso' => $curso, 'turmas' => $turmas, 'tags' => $tags]);
    }

    public function show($id)
    {
        $curso = Curso::find($id);
        $turmas = Turma::all();
        return Inertia::render('Painel/Cursos/Detalhes', ['curso' => $curso, 'turmas' => $turmas]);
    }

    public function store(Request $request) {
        
        $request->validate([
            'nome' => 'required',
            'situacao' => 'required',
            'link_video_apresentacao' => 'required',
            'objetivos' => 'required',
            'conteudo_programatico' => 'required',
            'campo_atuacao' => 'required',
            'descricao' => 'required',
            'destaque' => 'required',
            'tag' => 'required|array'
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        $nomeTag = $request->tag;
        $Tags = Tag::whereIn('id', $nomeTag)->get();
        $nomesDastags = [];
    
        foreach ($Tags as $Tag) {
            $nomesDastags[] = $Tag->nome;
        }
    
        $nomesConcatenados = implode(', ', $nomesDastags);

        $curso = Curso::create([
            'nome' => $request->nome,
            'tag' => $nomesConcatenados,
            'situacao' => $request->situacao,
            'link_video_apresentacao' => $request->link_video_apresentacao,
            'objetivos' => $request->objetivos,
            'conteudo_programatico' => $request->conteudo_programatico,
            'campo_atuacao' => $request->campo_atuacao,
            'destaque' => $request->destaque,
            'descricao' => $request->descricao,
            'created_by' => auth()->user()->id,
        ]);

        if ($request->file('imagem')) {
            $path = Storage::putFile('cursos/' . $curso->id, $request->file('imagem'));
            $curso->imagem = $path;
        }

        $curso->save();
           
        return redirect()->route('painel.cursos')->with('response', $curso);
    }

    public function update(Request $request, $id) {
        $request->validate([
            'nome' => 'required',
            'situacao' => 'required',
            'link_video_apresentacao' => 'required',
            'objetivos' => 'required',
            'conteudo_programatico' => 'required',
            'campo_atuacao' => 'required',
            'descricao' => 'required',
            'destaque' => 'required',
            'tag' => 'required'
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        $nomeTag = $request->tag;
        $Tags = Tag::whereIn('id', $nomeTag)->get();
        $nomesDastags = [];
    
        foreach ($Tags as $Tag) {
            $nomesDastags[] = $Tag->nome;
        }
    
        $nomesConcatenados = implode(', ', $nomesDastags);

        $curso = Curso::find($id);
        $curso->nome = $request->nome;
        $curso->situacao = $request->situacao;
        $curso->link_video_apresentacao = $request->link_video_apresentacao;
        $curso->objetivos = $request->objetivos;
        $curso->conteudo_programatico = $request->conteudo_programatico;
        $curso->campo_atuacao = $request->campo_atuacao;
        $curso->descricao = $request->descricao;
        $curso->destaque = $request->destaque;
        $curso->tag = $nomesConcatenados;

        $curso->updated_by = auth()->user()->id;
        if($request->file('imagem')){
            $path = Storage::putFile('cursos/'.$curso->id, $request->file('imagem'));
            $curso->imagem = $path;
        }

        $curso->save();

        return redirect()->route('painel.cursos')->with('response', $curso);
    }

    public function destroy(Request $request) {

        $id = $request->id;

        $curso = is_array($id) ? Curso::destroy($id) : Curso::findOrFail($id)->delete();

        return redirect()->route('painel.cursos')->with('response', $curso);
    }
}
