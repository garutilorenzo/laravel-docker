<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\TipoArquivo;
use Spatie\Activitylog\Models\Activity;

class TipoArquivoController extends Controller
{
    // public function __construct()
    // {
    //     $this->middleware(['permission:Index Tipo de Arquivos|Criar Tipo de Arquivos|Editar Tipo de Arquivos|Excluir Tipo de Arquivos|Importar Tipo de Arquivos|Exportar Tipo de Arquivos']);
    // }

    public function index()
    {
        $tiposArquivo = TipoArquivo::with('criadoPor', 'modificadoPor')->get();
        return Inertia::render('Painel/TipoArquivos/Index', [
            'tiposArquivo' => $tiposArquivo
        ]);
    }

    public function create()
    {
        return Inertia::render('Painel/TipoArquivos/Novo');
    }

    public function edit(Request $request, $id)
    {
        $tipoArquivo = TipoArquivo::find($id);
        
        return Inertia::render('Painel/TipoArquivos/Editar', 
        ['tipoArquivo' => $tipoArquivo]);
    }

    public function store(Request $request) {

        $request->validate([
            'nome' => 'required',
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        $tipoArquivo = TipoArquivo::create([
            'nome' => $request->nome,
            'created_by' => auth()->user()->id,
        ]);


        return redirect()->route('painel.tipoarquivo')->with('response', $tipoArquivo);
    }
    public function update(Request $request, $id) {
        $request->validate([
            'nome' => 'required',
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        $tipoArquivo = TipoArquivo::find($id);
        $tipoArquivo->nome = $request->nome;

        $tipoArquivo->updated_by = auth()->user()->id;

        $tipoArquivo->save();

        return redirect()->route('painel.tipoarquivo')->with('response', $tipoArquivo);
    }

    public function destroy(Request $request) {

        $id = $request->id;

        $tipoArquivo = is_array($id) ? TipoArquivo::destroy($id) : TipoArquivo::findOrFail($id)->delete();

        return redirect()->route('painel.tipoarquivo')->with('response', $tipoArquivo);
    }
    
    public function log(Request $request, $id)
    {
        $tipoArquivo = TipoArquivo::with('criadoPor', 'modificadoPor')->findOrFail($id);
        $logs = Activity::where('subject_type', TipoArquivo::class)
            ->where('subject_id', $tipoArquivo->id)
            ->with('causer')
            ->get();
        return Inertia::render('Painel/TipoArquivos/Log', [
            'tipoArquivo' => $tipoArquivo,
            'logs' => $logs,
        ]);
    }
}
