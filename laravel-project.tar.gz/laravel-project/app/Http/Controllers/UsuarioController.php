<?php

namespace App\Http\Controllers;

use App\Models\User;
use Inertia\Inertia;
use Illuminate\Http\Request;
use App\Models\Role;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\DB;


class UsuarioController extends Controller
{
    public function __construct()
    {
        // $this->middleware(['permission:Index Usuarios|Criar Usuarios|Editar Usuarios|Excluir Usuarios|Importar Usuarios|Exportar Usuarios']);
    }

    public function index()
    {
        $usuarios = User::with('permissions', 'roles')->get();
        $roles = Role::all();
        $permissions = Permission::all();
        return Inertia::render('Painel/Gestao/Usuarios/Index', [
            'usuarios' => $usuarios,
            'permissions' => $permissions,
            'roles' => $roles,
        ]);
    }

    public function show($id)
    {
        $usuarios = User::with('permissions', 'roles')->find($id);
        return Inertia::render('Painel/Gestao/Usuarios/Detalhes', [
            'usuarios' => $usuarios,
        ]);
    }

    public function create()
    {
        $permissions = Permission::all();
        $roles = Role::all();
        return Inertia::render('Painel/Gestao/Usuarios/Novo', [
            'permissions' => $permissions,
            'roles' => $roles
            
        ]);
    }

    public function store(Request $request)
    {
        $Users = User::all();
        
        // $role = Role::find($request->role);
        // if ($role) {
        //     $roleName = $role->name;
        // } else {
        //     // Lide com o cenário em que o papel com o ID fornecido não foi encontrado
        //     $roleName = null;
        // }
        
        $request->validate([
            'name' => 'required',
            'cpf' => 'required',
            'telefone' => 'required',
            'email' => 'required',
            'data_nascimento' => 'required',
            'role' => 'required'
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        // Verifica se o usuário já existe com o mesmo nome, CPF e email
        foreach ($Users as $user) {
            if ($user->name !== $request->name || $user->email !== $request->email || $user->cpf !== $request->cpf) {

                $user = User::create([
                    'name' => $request->name,
                    'cpf' => $request->cpf,
                    'telefone' => $request->telefone,
                    'email' => $request->email,
                    'data_nascimento' => $request->data_nascimento,
                    'role' => $request->$request->role,
                    'created_by' => auth()->user()->id,
                ]);

                if ($request->file('imagem')) {
                    $path = Storage::putFile('usuarios/' . $user->id, $request->file('imagem'));
                    $user->imagem = $path;
                }

                
                $user->save();
                $user->assignRole($request->input('role'));
                return redirect()->route('painel.gestao.usuarios')->with('response', $user);
            } else {
                echo "<script>window.confirm('Por gentilez corrija os campos')</script>";
            }
        }
    }

    public function edit(Request $request, $id)
    {
        $usuarios = User::with('permissions', 'roles')->find($id);

        $permissions = Permission::all();
        $roles = Role::all();

        return Inertia::render('Painel/Gestao/Usuarios/Editar', [
            'usuarios' => $usuarios,
            'roles' => $roles,
            'permissions' => $permissions
        ]);
    }

    public function update(Request $request, $id)
    {
        $role = Role::find($request->role);
        if ($role) {
            $roleName = $role->name;
        } else {
            $roleName = null;
        }

        $request->validate([
            'name' => 'required',
            'cpf' => 'required',
            'telefone' => 'required',
            'email' => 'required',
            'data_nascimento' => 'required',
            'role' => 'required'
        ], [
            'required' => 'O campo é obrigatório',
        ]);

        $usuario = User::find($id);
        $usuario->name = $request->name;
        $usuario->cpf = $request->cpf;
        $usuario->telefone = $request->telefone;
        $usuario->email = $request->email;
        $usuario->role = $request->role;
        $usuario->data_nascimento = $request->data_nascimento;
        $usuario->updated_by = auth()->user()->id;

        //$usuario->email = $request->email;
        // if ($request->password)
        //     $usuario->password = Hash::make($request->password);
        // if ($request->situacao)
        //     $usuario->situacao = $request->situacao;

        $usuario->save();

        DB::table('model_has_roles')->where('model_id', $id)->delete();

        $usuario->assignRole($request->input('role'));
        
        activity()
            ->causedBy(auth()->user())
            ->performedOn($usuario)
            ->withProperties(['permissao' => 'editar usuario'])
            ->log('Usuário atualizado');

        return redirect()->route('painel.gestao.usuarios')->with('response', $usuario);
    }
    public function destroy(Request $request)
    {

        $id = $request->id;

        $usuario = is_array($id) ? User::destroy($id) : User::findOrFail($id)->delete();

        activity()
            ->causedBy(auth()->user())
            //            ->performedOn($usuario)
            ->withProperties(['permissao' => 'deletar usuario'])
            ->log('Usuário removido');

        return redirect()->route('painel.gestao.usuarios')->with('response', $usuario);
    }

    public function permission(Request $request, User $user)
    {
        dd($request->all());
        // Obtenha as permissões selecionadas no pedido.
        $selectedPermissions = $request->input('permissions', []);

        // Obtenha todas as permissões do banco de dados.
        $allPermissions = Permission::all();

        // Revogue todas as permissões existentes para o usuário.
        $user->revokePermissionTo($allPermissions);

        // Conceda as novas permissões selecionadas.
        $user->givePermissionTo($selectedPermissions);

        return response()->json(['message' => 'Permissões atualizadas com sucesso']);
    }
}
