<?php

namespace App\Models;

use Spatie\Permission\Models\Role as Model;

class Role extends Model
{

}