<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Tag extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [

        'nome',
        'situacao',
        'categoria',
        'nivel',
        'faixa_etaria',
        'turno',
        'modalidade',
        'horas_curso',
        'resumo',
        'vagas',
        'data_inicio',
        'dias_semana',
        'edital_id',
        'curso_id',
        'created_by',
        'updated_by',
        'hora_inicio',
        'hora_termino',
    ];

    public function edital()
    {
        return $this->belongsTo(Edital::class, 'edital_id', 'id');
    }

    public function curso()
    {
        return $this->belongsTo(Curso::class, 'curso_id', 'id');
    }

    public function inscricoes()
    {
        return $this->hasMany(Inscricao::class, 'turma_id', 'id');
    }

    public function criadoPor()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function modificadoPor()
    {
        return $this->belongsTo(User::class, 'updated_by', 'id');
    }
}
