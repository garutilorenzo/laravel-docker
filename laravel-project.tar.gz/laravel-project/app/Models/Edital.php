<?php

namespace App\Models;

use App\CustomLog\EditalLog\LogOptions;
use App\CustomLog\EditalLog\Traits\LogsActivity;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Edital extends Model
{
    use HasFactory, SoftDeletes, LogsActivity;

    protected $table = "editais";

    protected $fillable = [
        'id',
        'nome',
        'situacao',
        'categoria',
        'modalidade',
        'agendar_publicacao',
        'udepi',
        'dt_publicacao',
        'dt_fim_edital',
        'dt_inicio_inscricao',
        'dt_fim_inscricao',
        'contagem_editais',
        'documentos_necessarios',
        'numero_edital',
        'municipio_id',
        'created_by',
        'updated_by',
        'escola_id',
        'created_by',
        'updated_by',
    ];

    public function documentos(){
        return $this->hasMany(Documento::class, 'edital_id', 'id');
    }

    public function escola(){
        return $this->belongsTo(Escola::class, 'escola_id', 'id');
    }

    public function criadoPor(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function modificadoPor(){
        return $this->belongsTo(User::class, 'updated_by', 'id');
    }

    public function documentosExigidos() {
        return $this->belongsToMany(TipoArquivo::class);
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logFillable()
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs();
    }
}
