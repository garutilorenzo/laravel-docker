<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Inscricao extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'inscricoes';

    protected $fillable = [
        'nome_completo',
        'password',
        'cpf',
        'tipo',
        'rede',
        'email',
        'email_confirmation',
        'raca',
        'sexo',
        'telefone',
        'telefone_alternativo',
        'cep',
        'municipio',
        'estado', 
        'logradouro',
        'numero',
        'complemento',
        'bairro',
        'data_nascimento',
        'nome_mae',
        'escolaridade',
        'origem_escolar',
        'nis_pis',
        'programa_social',
        'outro_programa_social',
        'deficiencia',
        'outra_deficiencia',
        'como_conheceu',
        'outro_como_conheceu',
        'situacao',
        'turma_id',
        'created_by',
        'updated_by',
    ];

    public function turma(){
        return $this->belongsTo(Turma::class, 'turma_id', 'id');
    }

    public function comprovantes(){
        return $this->hasMany(Comprovante::class, 'inscricao_id', 'id');
    }

    public function criadoPor(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function modificadoPor(){
        return $this->belongsTo(User::class, 'updated_by', 'id');
    }
}
