<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Curso extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $fillable = [
        'nome',
        'situacao',
        'link_video_apresentacao',
        'popularidade',
        'avaliacao',
        'carga_horaria',
        'faixa_etaria',
        'nivel',
        'imagem',
        'conteudo',
        'rede',
        'destaque',
        'eixo_tecnologico',
        'objetivos',
        'conteudo_programatico',
        'campo_atuacao',
        'descricao',
        'video',
        'resumo',
        'trilha_informativa',
        'curso_tecnico',
        'qualificacao',
        'tag',
        'created_by',
        'updated_by',
        
    ];

    public function criadoPor(){
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function modificadoPor(){
        return $this->belongsTo(User::class, 'updated_by', 'id');
    }
}
