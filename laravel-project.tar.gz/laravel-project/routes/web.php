<?php

use Inertia\Inertia;
use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Application;
use App\Http\Controllers\LogController;
use App\Http\Controllers\TagController;
use App\Http\Controllers\CursoController;
use App\Http\Controllers\GrupoController;
use App\Http\Controllers\TurmaController;
use App\Http\Controllers\EditalController;
use App\Http\Controllers\EscolaController;
use App\Http\Controllers\GestaoController;
use App\Http\Controllers\PortalController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SelecaoController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DocumentoController;
use App\Http\Controllers\InscricaoController;
use App\Http\Controllers\MunicipioController;
use App\Http\Controllers\PermissaoController;
use App\Http\Controllers\TipoArquivoController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'canVerifyEmail' => Route::has('verifyemail'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::group(['prefix' => 'portal'], function () {
    Route::get('/', [PortalController::class, 'index'])->name('portal.index');
});

Route::group(['prefix' => 'selecao'], function () {
    Route::get('/', [SelecaoController::class, 'index'])->name('selecao.index');
    Route::post('/', [SelecaoController::class, 'store'])->name('selecao.store');
    Route::get('/confirmacao', [SelecaoController::class, 'confirmacao'])->name('selecao.confirmacao');
    Route::get('/confirmacao/{inscricao_id}', [SelecaoController::class, 'confirmacao'])->name('selecao.confirmacao.id');
});

Route::group([
        'middleware' => ['auth', 'verified']
], function () {
    Route::get('/logs', [LogController::class, 'index'])->name('logs');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Escolas
    Route::group(['prefix' => 'escolas'], function () {
        Route::get('/', [EscolaController::class, 'index'])->name('painel.escolas')->middleware('permission:Index Escolas');;
        Route::get('/detalhes/{id}', [EscolaController::class, 'show'])->name('painel.escolas.show');
        Route::get('/novo', [EscolaController::class, 'create'])->name('painel.escolas.create');
        Route::post('/', [EscolaController::class, 'store'])->name('painel.escolas.store');
        Route::get('/editar/{id}', [EscolaController::class, 'edit'])->name('painel.escolas.editar');
        Route::patch('/{id}', [EscolaController::class, 'update'])->name('painel.escolas.update');
        Route::post('/deletar', [EscolaController::class, 'destroy'])->name('painel.escolas.destroy');
        Route::get('/log/{id}', [EscolaController::class, 'log'])->name('painel.escolas.log');
    });

    // Municipios
    Route::group(['prefix' => 'municipios'], function () {
        Route::get('/', [MunicipioController::class, 'index'])->name('painel.municipios')->middleware('permission:Index Municipios');;
        Route::get('/detalhes/{id}', [MunicipioController::class, 'show'])->name('painel.municipios.show');
        Route::get('/novo', [MunicipioController::class, 'create'])->name('painel.municipios.create');
        Route::post('/', [MunicipioController::class, 'store'])->name('painel.municipios.store');
        Route::get('/editar/{id}', [MunicipioController::class, 'edit'])->name('painel.municipios.editar');
        Route::patch('/{id}', [MunicipioController::class, 'update'])->name('painel.municipios.update');
        Route::post('/deletar', [MunicipioController::class, 'destroy'])->name('painel.municipios.destroy');
        Route::get('/log/{id}', [MunicipioController::class, 'log'])->name('painel.municipios.log');
    });

    // Edital
    Route::group(['prefix' => 'editais'], function () {
        Route::get('/', [EditalController::class, 'index'])->name('painel.editais')->middleware('permission:Index Editais');
        Route::get('/detalhes/{id}', [EditalController::class, 'show'])->name('painel.editais.show');
        Route::get('/novo', [EditalController::class, 'create'])->name('painel.editais.create');
        Route::post('/', [EditalController::class, 'store'])->name('painel.editais.store');
        Route::get('/editar/{id}', [EditalController::class, 'edit'])->name('painel.editais.editar');
        Route::patch('/{id}', [EditalController::class, 'update'])->name('painel.editais.update');
        Route::post('/deletar', [EditalController::class, 'destroy'])->name('painel.editais.destroy');
        Route::post('/painel/editais/{id}', [EditalController::class, 'autoupdate'])->name('painel.editais.autoupdate');
    });

    // turmas
    Route::group(['prefix' => 'turmas'], function () {
        Route::get('/', [TurmaController::class, 'index'])->name('painel.turmas')->middleware('permission:Index Turmas');;
        Route::get('/detalhes/{id}', [TurmaController::class, 'show'])->name('painel.turmas.show');
        Route::get('/novo', [TurmaController::class, 'create'])->name('painel.turmas.create');
        Route::post('/', [TurmaController::class, 'store'])->name('painel.turmas.store');
        Route::get('/editar/{id}', [TurmaController::class, 'edit'])->name('painel.turmas.editar');
        Route::patch('/{id}', [TurmaController::class, 'update'])->name('painel.turmas.update');
        Route::post('/deletar', [TurmaController::class, 'destroy'])->name('painel.turmas.destroy');
        Route::post('/reuse', [TurmaController::class, 'reuse'])->name('painel.turmas.reuse');
    });

    // cursos de Cursos
    Route::group(['prefix' => 'cursos'], function () {
        Route::get('/', [CursoController::class, 'index'])->name('painel.cursos')->middleware('permission:Index Cursos');;
        Route::get('/detalhes/{id}', [CursoController::class, 'show'])->name('painel.cursos.show');
        Route::get('/novo', [CursoController::class, 'create'])->name('painel.cursos.create');
        Route::post('/', [CursoController::class, 'store'])->name('painel.cursos.store');
        Route::get('/editar/{id}', [CursoController::class, 'edit'])->name('painel.cursos.editar');
        Route::patch('/{id}', [CursoController::class, 'update'])->name('painel.cursos.update');
        Route::post('/deletar', [CursoController::class, 'destroy'])->name('painel.cursos.destroy');
    });

    // Inscrições
    Route::group(['prefix' => 'inscricoes'], function () {
        Route::get('/', [InscricaoController::class, 'index'])->name('painel.inscricoes')->middleware('permission:Index Inscricoes');;
        Route::get('/detalhes/{id}', [InscricaoController::class, 'show'])->name('painel.inscricoes.show');
        Route::get('/novo', [InscricaoController::class, 'create'])->name('painel.inscricoes.create');
        Route::post('/', [InscricaoController::class, 'store'])->name('painel.inscricoes.store');
        Route::get('/editar/{id}', [InscricaoController::class, 'edit'])->name('painel.inscricoes.editar');
        Route::patch('/{id}', [InscricaoController::class, 'update'])->name('painel.inscricoes.update');
        Route::post('/deletar', [InscricaoController::class, 'destroy'])->name('painel.inscricoes.destroy');
    });

    // Gestão
    Route::group(['prefix' => 'gestao'], function () {
        Route::get('/permissoes', [GestaoController::class, 'permissoes'])->name('painel.gestao.permissoes')->middleware('permission:Index Permissoes');;
        Route::group(['prefix' => 'usuarios'], function() {
            Route::get('/', [UsuarioController::class, 'index'])->name('painel.gestao.usuarios');
            Route::get('/detalhes/{id}', [UsuarioController::class, 'show'])->name('painel.gestao.usuarios.show');
            Route::get('/novo', [UsuarioController::class, 'create'])->name('painel.gestao.usuarios.create');
            Route::post('/', [UsuarioController::class, 'store'])->name('painel.gestao.usuarios.store');
            Route::get('/editar/{id}', [UsuarioController::class, 'edit'])->name('painel.gestao.usuarios.editar');
            Route::patch('/{id}', [UsuarioController::class, 'update'])->name('painel.gestao.usuarios.update');
            Route::post('/permissoes/{id}', [UsuarioController::class, 'permission'])->name('painel.gestao.usuarios.permission');
            Route::post('/deletar', [UsuarioController::class, 'destroy'])->name('painel.gestao.usuarios.destroy');
        });

        Route::group(['prefix' => 'grupos'], function () { 
            Route::get('/', [GrupoController::class, 'index'])->name('painel.gestao.grupos');
            Route::get('/novo', [GrupoController::class, 'create'])->name('painel.gestao.grupos.create');
            Route::post('/', [GrupoController::class, 'store'])->name('painel.gestao.grupos.store');
            Route::get('/editar/{id}', [GrupoController::class, 'edit'])->name('painel.gestao.grupos.editar');
            Route::patch('/{id}', [GrupoController::class, 'update'])->name('painel.gestao.grupos.update');
            Route::delete('/{id}', [GrupoController::class, 'destroy'])->name('painel.gestao.grupos.destroy');
        });

        // Permissions
        Route::group(['prefix' => 'permissoes'], function () {
            Route::get('/', [PermissionController::class, 'index'])->name('painel.gestao.permissoes')->middleware('permission:Index Permissoes');;
            Route::get('/detalhes/{id}', [PermissionController::class, 'show'])->name('painel.gestao.permissoes.show');
            Route::get('/novo', [PermissionController::class, 'create'])->name('painel.gestao.permissoes.create');
            Route::post('/', [PermissionController::class, 'store'])->name('painel.gestao.permissoes.store');
            Route::get('/editar/{id}', [PermissionController::class, 'edit'])->name('painel.gestao.permissoes.editar');
            Route::patch('/{id}', [PermissionController::class, 'update'])->name('painel.gestao.permissoes.update');
            Route::post('/deletar/{id}', [PermissionController::class, 'destroy'])->name('painel.gestao.permissoes.destroy');
        });

        // Roles
        Route::group(['prefix' => 'roles'], function () {
            Route::get('/', [RoleController::class, 'index'])->name('painel.gestao.roles')->middleware('permission:Index Nivel de Acesso');;
            Route::get('/detalhes/{id}', [RoleController::class, 'show'])->name('painel.gestao.roles.show');
            Route::get('/novo', [RoleController::class, 'create'])->name('painel.gestao.roles.create');
            Route::post('/', [RoleController::class, 'store'])->name('painel.gestao.roles.store');
            Route::get('/editar/{id}', [RoleController::class, 'edit'])->name('painel.gestao.roles.editar');
            Route::patch('/{id}', [RoleController::class, 'update'])->name('painel.gestao.roles.update');
            Route::post('/deletar/{id}', [RoleController::class, 'destroy'])->name('painel.gestao.roles.destroy');
        });
    });

    //Tags
    Route::group(['prefix' => 'tags'], function () { 
        Route::get('/', [TagController::class, 'index'])->name('painel.tags')->middleware('permission:Index Tags');;
        Route::get('/detalhes/{id}', [TagController::class, 'show'])->name('painel.tags.show');
        Route::get('/novo', [TagController::class, 'create'])->name('painel.tags.create');
        Route::post('/', [TagController::class, 'store'])->name('painel.tags.store');
        Route::get('/editar/{id}', [TagController::class, 'edit'])->name('painel.tags.editar');
        Route::patch('/{id}', [TagController::class, 'update'])->name('painel.tags.update');
        Route::delete('/deletar', [TagController::class, 'destroy'])->name('painel.tags.destroy');
    });

    // Documentos
    Route::group(['prefix' => 'documentos'], function () {
        Route::post('/', [DocumentoController::class, 'store'])->name('painel.documentos.store');
        Route::patch('/{id}', [DocumentoController::class, 'update'])->name('painel.documentos.update');
        Route::delete('/{id}', [DocumentoController::class, 'destroy'])->name('painel.documentos.destroy');
    });

    // Tipos de Arquivos
    Route::group(['prefix' => 'tipo-arquivo'], function () {
        Route::get('/', [TipoArquivoController::class, 'index'])->name('painel.tipoarquivo');
        Route::get('/novo', [TipoArquivoController::class, 'create'])->name('painel.tipoarquivo.create');
        Route::post('/', [TipoArquivoController::class, 'store'])->name('painel.tipoarquivo.store');
        Route::get('/editar/{id}', [TipoArquivoController::class, 'edit'])->name('painel.tipoarquivo.editar');
        Route::patch('/{id}', [TipoArquivoController::class, 'update'])->name('painel.tipoarquivo.update');
        Route::post('/deletar', [TipoArquivoController::class, 'destroy'])->name('painel.tipoarquivo.destroy');
        Route::get('/log/{id}', [TipoArquivoController::class, 'log'])->name('painel.tipoarquivo.log');
    });

    // Perfil
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';